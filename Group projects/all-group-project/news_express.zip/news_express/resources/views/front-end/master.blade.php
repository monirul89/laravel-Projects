<!DOCTYPE html>
<html>
<head>
    <title>@yield('title')</title>
    <!-- Custom Theme files -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Express News Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
    <link href="{{ asset('/') }}front/css/bootstrap.css" rel='stylesheet' type='text/css' />
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="{{ asset('/') }}front/js/jquery.min.js"></script>
    <!-- Custom Theme files -->
    <link href="{{ asset('/') }}front/css/style.css" rel="stylesheet" type="text/css" media="all" />
    <!-- web-fonts -->
    <link href='//fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
    <link href='//fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
</head>
<body>
<!-- header-section-starts-here -->
@include('front-end.includes.header')
<!-- header-section-ends-here -->
@include('front-end.includes.breaking-news')
<!-- content-section-starts-here -->
<div class="main-body">
    <div class="wrap">
        @yield('body')
        @include('front-end.includes.sidebar')
        <div class="clearfix"></div>
    </div>
</div>
<!-- content-section-ends-here -->
<!-- footer-section-starts-here -->
@include('front-end.includes.footer')
<!-- footer-section-ends-here -->

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- for bootstrap working -->
<script type="text/javascript" src="{{ asset('/') }}front/js/bootstrap.js"></script>
<!-- //for bootstrap working -->
<script src="{{ asset('/') }}front/js/responsiveslides.min.js"></script>
<script>
    $(function () {
        $("#slider").responsiveSlides({
            auto: true,
            nav: true,
            speed: 500,
            namespace: "callbacks",
            pager: true,
        });
    });
</script>
<script type="text/javascript" src="{{ asset('/') }}front/js/move-top.js"></script>
<script type="text/javascript" src="{{ asset('/') }}front/js/easing.js"></script>
<!--/script-->
<script type="text/javascript">
    jQuery(document).ready(function($) {
        $(".scroll").click(function(event){
            event.preventDefault();
            $('html,body').animate({scrollTop:$(this.hash).offset().top},900);
        });
    });
</script>
<script type="text/javascript">
    $(document).ready(function() {
        /*
        var defaults = {
        wrapID: 'toTop', // fading element id
        wrapHoverID: 'toTopHover', // fading element hover id
        scrollSpeed: 1200,
        easingType: 'linear'
        };
        */
        $().UItoTop({ easingType: 'easeOutQuart' });
    });
</script>
<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
<!---->
</body>
</html>