<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Manage Category</h4>
                </div>
                <div class="panel-body">
                    <h3 class="text-success text-center"><?php echo e(Session::get('message')); ?></h3>
                    <br/>
                    <table class="table table-bordered">
                        <tr class="bg-primary">
                            <th>Sl No</th>
                            <th> Sub Category Name</th>
                            <th>Category Name</th>
                            <th>Category Description</th>
                            <th>Publication Status</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($subCategory->sub_category_name); ?></td>
                                <td><?php echo e($subCategory->category_name); ?></td>
                                <td><?php echo e($subCategory->sub_category_description); ?></td>
                                <td><?php echo e($subCategory->publication_status == 1 ? 'Published':'Unpublished'); ?></td>
                                <td>
                                    <?php if($subCategory->publication_status == 1): ?>
                                        <a href="<?php echo e(route('unpublished-sub-category',['id'=>$subCategory->id])); ?>" class="btn btn-info btn-xs">
                                            <span class="glyphicon glyphicon-arrow-up"></span>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('published-sub-category',['id'=>$subCategory->id])); ?>" class="btn btn-warning btn-xs">
                                            <span class="glyphicon glyphicon-arrow-down"></span>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('edit-sub-category',['id'=>$subCategory->id])); ?>" class="btn btn-success btn-xs">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>
                                    <a href="<?php echo e(route('delete-sub-category',['id'=>$subCategory->id])); ?>" onclick="return confirm('Are you sure to delete this!!')" class="btn btn-danger btn-xs">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>