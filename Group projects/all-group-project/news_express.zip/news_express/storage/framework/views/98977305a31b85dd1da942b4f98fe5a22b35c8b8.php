<div class="wrap">
    <div class="move-text">
        <div class="breaking_news">
            <h2>Breaking News</h2>
        </div>
        <div class="marquee">
            <div class="marquee1"><a class="breaking" href="single.html">>>The standard chunk of Lorem Ipsum used since the 1500s is reproduced..</a></div>
            <div class="marquee2"><a class="breaking" href="single.html">>>At vero eos et accusamus et iusto qui blanditiis praesentium voluptatum deleniti atque..</a></div>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
        <script type="text/javascript" src="<?php echo e(asset('/')); ?>front/js/jquery.marquee.min.js"></script>
        <script>
            $('.marquee').marquee({
                duration:10000,
                pauseOnHover: true

            });

            //@ sourceURL=pen.js
        </script>
    </div>
</div>