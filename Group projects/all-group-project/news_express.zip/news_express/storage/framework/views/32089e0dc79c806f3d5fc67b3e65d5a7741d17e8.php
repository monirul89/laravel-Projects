<?php $__env->startSection('title'); ?>
    Entertainment
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="col-md-8 content-left">
        <div class="slider">
            <div class="callbacks_container">
                <ul class="rslides" id="slider">
                    <li>
                        <img src="<?php echo e(asset('/')); ?>front/images/e1.jpg" alt="">
                        <div class="caption">
                            <a href="<?php echo e(route('single-view')); ?>">Lorem Ipsum is simply dummy text of the printing and typesetting industry</a>
                        </div>
                    </li>
                    <li>
                        <img src="<?php echo e(asset('/')); ?>front/images/e2.jpg" alt="">
                        <div class="caption">
                            <a href="<?php echo e(route('single-view')); ?>">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque</a>
                        </div>
                    </li>
                    <li>
                        <img src="<?php echo e(asset('/')); ?>front/images/e3.jpg" alt="">
                        <div class="caption">
                            <a href="<?php echo e(route('single-view')); ?>">At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        <div class="articles entertainment">
            <header>
                <h3 class="title-head">Entertainment</h3>
            </header>
            <div class="article">
                <div class="article-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/ent1.jpg"></a>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Feb 25, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>104 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>"> The section of the mass media industry that focuses on presenting</a>
                    </div>
                    <div class="article-text">
                        <p>The standard chunk of Lorem Ipsum used since the 1500s. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" exact original.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="article">
                <div class="article-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/ent2.jpg"></a>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Jun 21, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>181 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>89</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>">There are many variations that focuses on presenting</a>
                    </div>
                    <div class="article-text">
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="article">
                <div class="article-left">
                    <iframe width="100%" src="https://www.youtube.com/embed/mbDg4OG7z4Y" frameborder="0" allowfullscreen></iframe>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Apr 11, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>2 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>54 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>18</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>">Contrary to popular belief, Lorem Ipsum is not simply random</a>
                    </div>
                    <div class="article-text">
                        <p>It is a long established fact that a reader will be distracted by the readable.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="article">
                <div class="article-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/ent3.jpg"></a>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Jan 17, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>1 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>144 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>74</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>">Lorem ipsum dolor sit amet, consectetur adipiscing elit</a>
                    </div>
                    <div class="article-text">
                        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="article">
                <div class="article-left">
                    <iframe width="100%" src="https://www.youtube.com/embed/GxXxvJYUpxk" frameborder="0" allowfullscreen></iframe>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Mar 14, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>250 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>68</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>">On the other hand, we denounce with righteous indignation</a>
                    </div>
                    <div class="article-text">
                        <p>It is a long established fact that a reader will be distracted by the readable.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>

        <div class="life-style">
            <header>
                <h3 class="title-head">Life Style</h3>
            </header>
            <div class="life-style-grids">
                <div class="life-style-left-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/l1.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader will be distracted.</a>
                </div>
                <div class="life-style-right-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/l2.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">There are many variations of passages of Lorem Ipsum available.</a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="life-style-grids">
                <div class="life-style-left-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/l3.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">Contrary to popular belief, Lorem Ipsum is not simply random text.</a>
                </div>
                <div class="life-style-right-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/l4.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="photos">
            <header>
                <h3 class="title-head">Photos</h3>
            </header>
            <div class="course_demo1">
                <ul id="flexiselDemo">
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/eg4.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/eg3.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/eg2.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/eg1.jpg" alt="" /></a>
                    </li>
                </ul>
            </div>
            <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
            <script type="text/javascript">
                $(window).load(function() {
                    $("#flexiselDemo").flexisel({
                        visibleItems: 4,
                        animationSpeed: 1000,
                        autoPlay: true,
                        autoPlaySpeed: 3000,
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: {
                            portrait: {
                                changePoint:480,
                                visibleItems: 2
                            },
                            landscape: {
                                changePoint:640,
                                visibleItems: 2
                            },
                            tablet: {
                                changePoint:768,
                                visibleItems: 3
                            }
                        }
                    });

                });
            </script>
            <script type="text/javascript" src="js/jquery.flexisel.js"></script>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>