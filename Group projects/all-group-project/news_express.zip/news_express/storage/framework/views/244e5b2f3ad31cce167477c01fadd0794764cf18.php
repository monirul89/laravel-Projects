<?php $__env->startSection('title'); ?>
    Business
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="col-md-8 content-left">
        <div class="articles sports">
            <header>
                <h3 class="title-head">Business</h3>
            </header>
            <div class="article">
                <div class="article-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/business1.jpg"></a>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Feb 25, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>104 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>"> The section of the mass media industry that focuses on presenting</a>
                    </div>
                    <div class="article-text">
                        <p>The standard chunk of Lorem Ipsum used since the 1500s. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" exact original.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="article">
                <div class="article-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/business2.jpg"></a>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Jun 21, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>181 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>89</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>">There are many variations that focuses on presenting</a>
                    </div>
                    <div class="article-text">
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="article">
                <div class="article-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/business3.jpg"></a>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Jan 17, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>1 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>144 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>74</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>">Lorem ipsum dolor sit amet, consectetur adipiscing elit</a>
                    </div>
                    <div class="article-text">
                        <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="article">
                <div class="article-left">
                    <iframe width="100%" src="https://www.youtube.com/embed/mbDg4OG7z4Y" frameborder="0" allowfullscreen></iframe>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Apr 11, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>2 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>54 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>18</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>">Contrary to popular belief, Lorem Ipsum is not simply random</a>
                    </div>
                    <div class="article-text">
                        <p>It is a long established fact that a reader will be distracted by the readable.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="article">
                <div class="article-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/business4.jpg"></a>
                </div>
                <div class="article-right">
                    <div class="article-title">
                        <p>On Apr 11, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>2 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>54 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>18</a></p>
                        <a class="title" href="<?php echo e(route('single-view')); ?>">Contrary to popular belief, Lorem Ipsum is not simply random</a>
                    </div>
                    <div class="article-text">
                        <p>It is a long established fact that a reader will be distracted by the readable.....</p>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="latest-articles">
            <div class="main-title-head">
                <header>
                    <h3 class="title-head">What's Hot</h3>
                </header>
            </div>
            <div class="world-news-grids">
                <div class="world-news-grid">
                    <img src="<?php echo e(asset('/')); ?>front/images/tech1.jpg" alt="" />
                    <a href="<?php echo e(route('single-view')); ?>" class="title">Lorem ipsum dolor sit amet, consectetur </a>
                    <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="world-news-grid">
                    <img src="<?php echo e(asset('/')); ?>front/images/tech5.jpg" alt="" />
                    <a href="<?php echo e(route('single-view')); ?>" class="title">Lorem ipsum dolor sit amet, consectetur </a>
                    <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="world-news-grid">
                    <img src="<?php echo e(asset('/')); ?>front/images/tech6.jpg" alt="" />
                    <a href="<?php echo e(route('single-view')); ?>" class="title">Lorem ipsum dolor sit amet, consectetur </a>
                    <p>Nulla quis lorem neque, mattis venenatis lectus. In interdum ullamcorper dolor eu mattis.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>