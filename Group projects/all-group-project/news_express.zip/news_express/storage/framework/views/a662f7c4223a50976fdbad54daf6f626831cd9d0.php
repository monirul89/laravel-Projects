<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="col-md-8 content-left">
        <div class="fashion">
            <div class="fashion-top">
                <div class="fashion-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f1.jpg" class="img-responsive" alt=""></a>
                    <div class="blog-poast-info">
                        <p class="fdate"><span class="glyphicon glyphicon-time"></span>On Jun 20, 2015 <a class="span_link1" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link1" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                    </div>
                    <h3><a href="<?php echo e(route('single-view')); ?>">Contrary to popular belief</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="fashion-right">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f2.jpg" class="img-responsive" alt=""></a>
                    <div class="blog-poast-info">
                        <p class="fdate"><span class="glyphicon glyphicon-time"></span>On Apr 18, 2015 <a class="span_link1" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link1" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                    </div>
                    <h3><a href="<?php echo e(route('single-view')); ?>">Lorem Ipsum is simply</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="fashion-top">
                <div class="fashion-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f3.jpg" class="img-responsive" alt=""></a>
                    <div class="blog-poast-info">
                        <p class="fdate"><span class="glyphicon glyphicon-time"></span>On Mar 28, 2015 <a class="span_link1" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link1" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                    </div>
                    <h3><a href="<?php echo e(route('single-view')); ?>">There are many variations</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="fashion-right">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f4.jpg" class="img-responsive" alt=""></a>
                    <div class="blog-poast-info">
                        <p class="fdate"><span class="glyphicon glyphicon-time"></span>On Feb 25, 2015 <a class="span_link1" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link1" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                    </div>
                    <h3><a href="<?php echo e(route('single-view')); ?>">Sed ut perspiciatis</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="fashion-top">
                <div class="fashion-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f5.jpg" class="img-responsive" alt=""></a>
                    <div class="blog-poast-info">
                        <p class="fdate"><span class="glyphicon glyphicon-time"></span>On Jan 28, 2015 <a class="span_link1" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link1" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                    </div>
                    <h3><a href="<?php echo e(route('single-view')); ?>">denouncing pleasure</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="fashion-right">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f6.jpg" class="img-responsive" alt=""></a>
                    <div class="blog-poast-info">
                        <p class="fdate"><span class="glyphicon glyphicon-time"></span>On Jan 08, 2015 <a class="span_link1" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link1" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                    </div>
                    <h3><a href="<?php echo e(route('single-view')); ?>">At vero eos et accusamus</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="fashion-top">
                <div class="fashion-left">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f7.jpg" class="img-responsive" alt=""></a>
                    <div class="blog-poast-info">
                        <p class="fdate"><span class="glyphicon glyphicon-time"></span>On Dec 29, 2014 <a class="span_link1" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link1" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>52</a></p>
                    </div>
                    <h3><a href="<?php echo e(route('single-view')); ?>">On the other hand</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="fashion-right">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f8.jpg" class="img-responsive" alt=""></a>
                    <div class="blog-poast-info">
                        <p class="fdate"><span class="glyphicon glyphicon-time"></span>On Dec 18, 2014 <a class="span_link1" href="#"><span class="glyphicon glyphicon-comment"></span>5 </a><a class="span_link1" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>22</a></p>
                    </div>
                    <h3><a href="<?php echo e(route('single-view')); ?>">blanditiis praesentium</a></h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                    <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="photos fashion-photos">
            <header>
                <h3 class="title-head">Gallery</h3>
            </header>
            <div class="course_demo1">
                <ul id="flexiselDemo">
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f2.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f3.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f8.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f6.jpg" alt="" /></a>
                    </li>
                </ul>
            </div>
            <link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" />
            <script type="text/javascript">
                $(window).load(function() {
                    $("#flexiselDemo").flexisel({
                        visibleItems: 4,
                        animationSpeed: 1000,
                        autoPlay: true,
                        autoPlaySpeed: 3000,
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: {
                            portrait: {
                                changePoint:480,
                                visibleItems: 2
                            },
                            landscape: {
                                changePoint:640,
                                visibleItems: 2
                            },
                            tablet: {
                                changePoint:768,
                                visibleItems: 3
                            }
                        }
                    });

                });
            </script>
            <script type="text/javascript" src="js/jquery.flexisel.js"></script>

            <div class="course_demo1">
                <ul id="flexiselDemo1">
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f1.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f4.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f7.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/f5.jpg" alt="" /></a>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
                $(window).load(function() {
                    $("#flexiselDemo1").flexisel({
                        visibleItems: 4,
                        animationSpeed: 1000,
                        autoPlay: true,
                        autoPlaySpeed: 3000,
                        pauseOnHover: true,
                        enableResponsiveBreakpoints: true,
                        responsiveBreakpoints: {
                            portrait: {
                                changePoint:480,
                                visibleItems: 2
                            },
                            landscape: {
                                changePoint:640,
                                visibleItems: 2
                            },
                            tablet: {
                                changePoint:768,
                                visibleItems: 3
                            }
                        }
                    });

                });
            </script>
        </div>


        <div class="life-style">
            <header>
                <h3 class="title-head">Life Style</h3>
            </header>
            <div class="life-style-grids">
                <div class="life-style-left-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/l1.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader will be distracted.</a>
                </div>
                <div class="life-style-right-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/l2.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">There are many variations of passages of Lorem Ipsum available.</a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="life-style-grids">
                <div class="life-style-left-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/l3.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">Contrary to popular belief, Lorem Ipsum is not simply random text.</a>
                </div>
                <div class="life-style-right-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/l4.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</a>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="sports-top">
            <div class="s-grid-left">
                <div class="cricket">
                    <header>
                        <h3 class="title-head">Business</h3>
                    </header>
                    <div class="c-sports-main">
                        <div class="c-image">
                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/bus1.jpg" alt="" /></a>
                        </div>
                        <div class="c-text">
                            <h6>Lorem Ipsum</h6>
                            <a class="power" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader</a>
                            <p class="date">On Feb 25, 2015</p>
                            <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="s-grid-small">
                        <div class="sc-image">
                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/bus2.jpg" alt="" /></a>
                        </div>
                        <div class="sc-text">
                            <h6>Lorem Ipsum</h6>
                            <a class="power" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader</a>
                            <p class="date">On Mar 21, 2015</p>
                            <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="s-grid-small">
                        <div class="sc-image">
                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/bus3.jpg" alt="" /></a>
                        </div>
                        <div class="sc-text">
                            <h6>Lorem Ipsum</h6>
                            <a class="power" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader</a>
                            <p class="date">On Jan 25, 2015</p>
                            <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="s-grid-small">
                        <div class="sc-image">
                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/bus4.jpg" alt="" /></a>
                        </div>
                        <div class="sc-text">
                            <h6>Lorem Ipsum</h6>
                            <a class="power" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader</a>
                            <p class="date">On Jul 19, 2015</p>
                            <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="s-grid-right">
                <div class="cricket">
                    <header>
                        <h3 class="title-popular">Technology</h3>
                    </header>
                    <div class="c-sports-main">
                        <div class="c-image">
                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/tec1.jpg" alt="" /></a>
                        </div>
                        <div class="c-text">
                            <h6>Lorem Ipsum</h6>
                            <a class="power" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader</a>
                            <p class="date">On Apr 22, 2015</p>
                            <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="s-grid-small">
                        <div class="sc-image">
                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/tec2.jpg" alt="" /></a>
                        </div>
                        <div class="sc-text">
                            <h6>Lorem Ipsum</h6>
                            <a class="power" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader</a>
                            <p class="date">On Jan 19, 2015</p>
                            <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="s-grid-small">
                        <div class="sc-image">
                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/tec3.jpg" alt="" /></a>
                        </div>
                        <div class="sc-text">
                            <h6>Lorem Ipsum</h6>
                            <a class="power" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader</a>
                            <p class="date">On Jun 25, 2015</p>
                            <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="s-grid-small">
                        <div class="sc-image">
                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/tec4.jpg" alt="" /></a>
                        </div>
                        <div class="sc-text">
                            <h6>Lorem Ipsum</h6>
                            <a class="power" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader</a>
                            <p class="date">On Jul 19, 2015</p>
                            <a class="reu" href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/more.png" alt="" /></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>