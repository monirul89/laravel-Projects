<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Manage News</h4>
                </div>
                <div class="panel-body">
                    <h3 class="text-success text-center"><?php echo e(Session::get('message')); ?></h3>
                    <br/>
                    <table class="table table-bordered">
                        <tr class="bg-primary">
                            <th>Sl No</th>
                            <th>News Title</th>
                            <th>Category Name</th>
                            <th>Short Description </th>
                            <th>Breaking News Status</th>
                            <th>News Image</th>
                            <th>Publication Status</th>
                            <th width="130">Action</th>
                        </tr>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $newses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($news->news_title); ?></td>
                                <td><?php echo e($news->category_name); ?></td>
                                <td><?php echo e($news->short_description); ?></td>
                                <td><?php echo e($news->breaking_news_status == 1 ? 'Yes':'No'); ?></td>
                                <td><img src="<?php echo e(asset($news->news_image)); ?>" alt=" " height="120" width="120" /></td>
                                <td><?php echo e($news->publication_status == 1 ? 'Published':'Unpublished'); ?></td>
                                <td>
                                    <?php if($news->breaking_news_status == 1): ?>
                                        <a href="<?php echo e(route('remove-breaking-news',['id'=>$news->id])); ?>" class="btn btn-primary btn-xs" title="Remove Breaking News">
                                            <span class="glyphicon glyphicon-pushpin"></span>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('make-breaking-news',['id'=>$news->id])); ?>" class="btn btn-warning btn-xs" title="Make Breaking News">
                                            <span class="glyphicon glyphicon-pushpin"></span>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('edit-news',['id'=>$news->id])); ?>" class="btn btn-success btn-xs" title="Edit News">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>
                                    <?php if($news->publication_status == 1): ?>
                                        <a href="<?php echo e(route('unpublished-news',['id'=>$news->id])); ?>" class="btn btn-info btn-xs" title="Unpublish News">
                                            <span class="glyphicon glyphicon-arrow-up"></span>
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('published-news',['id'=>$news->id])); ?>" class="btn btn-warning btn-xs" title="Publish News">
                                            <span class="glyphicon glyphicon-arrow-down"></span>
                                        </a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('view-news',['id'=>$news->id])); ?>" class="btn btn-success btn-xs" title="View News">
                                        <span class="glyphicon glyphicon-fullscreen"></span>
                                    </a>
                                    <a href="<?php echo e(route('delete-news',['id'=>$news->id])); ?>" onclick="return confirm('Are you sure to delete this!!')" class="btn btn-danger btn-xs" title="Delete News">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>