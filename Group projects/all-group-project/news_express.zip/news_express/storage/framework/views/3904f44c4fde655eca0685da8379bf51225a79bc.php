<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Edit Sub-Category Form</h4>
                </div>
                <div class="panel-body">
                    <?php echo e(Form::open(['route'=>'update-sub-category', 'method'=>'POST', 'name'=>'editSubCategoryForm', 'class'=>'form-horizontal', 'enctype'=>'multipart/form-data'])); ?>

                    <div class="form-group">
                        <label class="control-label col-md-4">Sub Category Name</label>
                        <div class="col-md-8">
                            <input type="text" name="sub_category_name" class="form-control" value="<?php echo e($subCategory->sub_category_name); ?>"/>
                            <input type="hidden" name="sub_category_id" class="form-control" value="<?php echo e($subCategory->id); ?>"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Category Name</label>
                        <div class="col-md-8">
                            <select name="category_id" class="form-control">
                                <option value=" ">--- Select Category Name ---</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Sub Category Description</label>
                        <div class="col-md-8">
                            <textarea name="sub_category_description" class="form-control"><?php echo e($subCategory->sub_category_description); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Publication Status</label>
                        <div class="col-md-8 radio">
                            <label><input type="radio" name="publication_status" value="1" <?php echo e($subCategory->publication_status == 1 ? 'checked':''); ?>/>Published</label>
                            <label><input type="radio" name="publication_status" value="0" <?php echo e($subCategory->publication_status == 0 ? 'checked':''); ?>/>Unpublished</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="Save Category Info"/>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
    <script>
        document.forms['editSubCategoryForm'].elements['category_id'].value='<?php echo e($subCategory->category_id); ?>';
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>