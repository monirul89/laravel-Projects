<?php $__env->startSection('title'); ?>
    Privacy & Policy
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="col-md-8 content-left">
        <div class="privacy">
            <h2 class="head">Privacy Policy</h2>
            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
            <p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</p>
            <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
            <ul>
                <li><a href="#">It is a long established fact that a reader will be distracted by the readable.</a></li>
                <li><a href="#">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old.</a></li>
                <li><a href="#">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration.</a></li>
                <li><a href="#">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</a></li>
                <li><a href="#">But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system.</a></li>
                <li><a href="#">At vero eos et accusamus et iusto odio dignissimos ducimus.</a></li>
                <li><a href="#">On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized.</a></li>
                <li><a href="#"> web sites still in their infancy. Various versions have evolved over the years.</a></li>
                <li><a href="#">These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled.</a></li>
                <li><a href="#">There are many variations of passages of Lorem Ipsum available, but the majority.</a></li>
                <li><a href="#">Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition.</a></li>
                <li><a href="#">It is a long established fact that a reader will be distracted by the readable.</a></li>
                <li><a href="#">The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</a></li>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>