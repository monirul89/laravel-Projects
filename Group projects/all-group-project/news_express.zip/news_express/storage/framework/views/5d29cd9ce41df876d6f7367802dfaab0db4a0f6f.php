<div class="col-md-4 side-bar">
    <div class="first_half">
        <div class="newsletter">
            <h1 class="side-title-head">Newsletter</h1>
            <p class="sign">Sign up to receive our free newsletters!</p>
            <form>
                <input type="text" class="text" value="Email Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email Address';}">
                <input type="submit" value="submit">
            </form>
        </div>
        <div class="list_vertical">
            <section class="accordation_menu">
                <div>
                    <input id="label-1" name="lida" type="radio" checked/>
                    <label for="label-1" id="item1"><i class="ferme"> </i>Popular Posts<i class="icon-plus-sign i-right1"></i><i class="icon-minus-sign i-right2"></i></label>
                    <div class="content" id="a1">
                        <div class="scrollbar" id="style-2">
                            <div class="force-overflow">
                                <div class="popular-post-grids">
                                    <div class="popular-post-grid">
                                        <div class="post-img">
                                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/bus2.jpg" alt="" /></a>
                                        </div>
                                        <div class="post-text">
                                            <a class="pp-title" href="<?php echo e(route('single-view')); ?>"> The section of the mass media industry</a>
                                            <p>On Feb 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>3 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a></p>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="popular-post-grid">
                                        <div class="post-img">
                                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/bus1.jpg" alt="" /></a>
                                        </div>
                                        <div class="post-text">
                                            <a class="pp-title" href="<?php echo e(route('single-view')); ?>"> Lorem Ipsum is simply dummy text printing</a>
                                            <p>On Apr 14 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>2 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a></p>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="popular-post-grid">
                                        <div class="post-img">
                                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/bus3.jpg" alt="" /></a>
                                        </div>
                                        <div class="post-text">
                                            <a class="pp-title" href="<?php echo e(route('single-view')); ?>">There are many variations of Lorem</a>
                                            <p>On Jun 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a></p>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="popular-post-grid">
                                        <div class="post-img">
                                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/bus4.jpg" alt="" /></a>
                                        </div>
                                        <div class="post-text">
                                            <a class="pp-title" href="<?php echo e(route('single-view')); ?>">Sed ut perspiciatis unde omnis iste natus</a>
                                            <p>On Jan 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>1 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a></p>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <input id="label-2" name="lida" type="radio"/>
                    <label for="label-2" id="item2"><i class="icon-leaf" id="i2"></i>Recent Posts<i class="icon-plus-sign i-right1"></i><i class="icon-minus-sign i-right2"></i></label>
                    <div class="content" id="a2">
                        <div class="scrollbar" id="style-2">
                            <div class="force-overflow">
                                <div class="popular-post-grids">
                                    <div class="popular-post-grid">
                                        <div class="post-img">
                                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/tec2.jpg" alt="" /></a>
                                        </div>
                                        <div class="post-text">
                                            <a class="pp-title" href="<?php echo e(route('single-view')); ?>"> The section of the mass media industry</a>
                                            <p>On Feb 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>3 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a></p>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="popular-post-grid">
                                        <div class="post-img">
                                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/tec1.jpg" alt="" /></a>
                                        </div>
                                        <div class="post-text">
                                            <a class="pp-title" href="<?php echo e(route('single-view')); ?>"> Lorem Ipsum is simply dummy text printing</a>
                                            <p>On Apr 14 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>2 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a></p>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="popular-post-grid">
                                        <div class="post-img">
                                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/tec3.jpg" alt="" /></a>
                                        </div>
                                        <div class="post-text">
                                            <a class="pp-title" href="<?php echo e(route('single-view')); ?>">There are many variations of Lorem</a>
                                            <p>On Jun 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a></p>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="popular-post-grid">
                                        <div class="post-img">
                                            <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/tec4.jpg" alt="" /></a>
                                        </div>
                                        <div class="post-text">
                                            <a class="pp-title" href="<?php echo e(route('single-view')); ?>">Sed ut perspiciatis unde omnis iste natus</a>
                                            <p>On Jan 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>1 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a></p>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <input id="label-3" name="lida" type="radio"/>
                    <label for="label-3" id="item3"><i class="icon-trophy" id="i3"></i>Comments<i class="icon-plus-sign i-right1"></i><i class="icon-minus-sign i-right2"></i></label>
                    <div class="content" id="a3">
                        <div class="scrollbar" id="style-2">
                            <div class="force-overflow">
                                <div class="response">
                                    <div class="media response-info">
                                        <div class="media-left response-text-left">
                                            <a href="#">
                                                <img class="media-object" src="<?php echo e(asset('/')); ?>front/images/icon1.png" alt="" />
                                            </a>
                                            <h5><a href="#">Username</a></h5>
                                        </div>
                                        <div class="media-body response-text-right">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,There are many variations of passages of Lorem Ipsum available,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                            <ul>
                                                <li>MARCH 21, 2015</li>
                                                <li><a href="<?php echo e(route('single-view')); ?>">Reply</a></li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="media response-info">
                                        <div class="media-left response-text-left">
                                            <a href="#">
                                                <img class="media-object" src="<?php echo e(asset('/')); ?>front/images/icon1.png" alt="" />
                                            </a>
                                            <h5><a href="#">Username</a></h5>
                                        </div>
                                        <div class="media-body response-text-right">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,There are many variations of passages of Lorem Ipsum available,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                            <ul>
                                                <li>MARCH 26, 2015</li>
                                                <li><a href="<?php echo e(route('single-view')); ?>">Reply</a></li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="media response-info">
                                        <div class="media-left response-text-left">
                                            <a href="#">
                                                <img class="media-object" src="<?php echo e(asset('/')); ?>front/images/icon1.png" alt="" />
                                            </a>
                                            <h5><a href="#">Username</a></h5>
                                        </div>
                                        <div class="media-body response-text-right">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,There are many variations of passages of Lorem Ipsum available,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                            <ul>
                                                <li>MAY 25, 2015</li>
                                                <li><a href="<?php echo e(route('single-view')); ?>">Reply</a></li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="media response-info">
                                        <div class="media-left response-text-left">
                                            <a href="#">
                                                <img class="media-object" src="<?php echo e(asset('/')); ?>front/images/icon1.png" alt="" />
                                            </a>
                                            <h5><a href="#">Username</a></h5>
                                        </div>
                                        <div class="media-body response-text-right">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,There are many variations of passages of Lorem Ipsum available,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                            <ul>
                                                <li>FEB 13, 2015</li>
                                                <li><a href="<?php echo e(route('single-view')); ?>">Reply</a></li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="media response-info">
                                        <div class="media-left response-text-left">
                                            <a href="#">
                                                <img class="media-object" src="<?php echo e(asset('/')); ?>front/images/icon1.png" alt="" />
                                            </a>
                                            <h5><a href="#">Username</a></h5>
                                        </div>
                                        <div class="media-body response-text-right">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,There are many variations of passages of Lorem Ipsum available,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                            <ul>
                                                <li>JAN 28, 2015</li>
                                                <li><a href="<?php echo e(route('single-view')); ?>">Reply</a></li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="media response-info">
                                        <div class="media-left response-text-left">
                                            <a href="#">
                                                <img class="media-object" src="<?php echo e(asset('/')); ?>front/images/icon1.png" alt="" />
                                            </a>
                                            <h5><a href="#">Username</a></h5>
                                        </div>
                                        <div class="media-body response-text-right">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,There are many variations of passages of Lorem Ipsum available,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                            <ul>
                                                <li>APR 18, 2015</li>
                                                <li><a href="<?php echo e(route('single-view')); ?>">Reply</a></li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                    <div class="media response-info">
                                        <div class="media-left response-text-left">
                                            <a href="#">
                                                <img class="media-object" src="<?php echo e(asset('/')); ?>front/images/icon1.png" alt="" />
                                            </a>
                                            <h5><a href="#">Username</a></h5>
                                        </div>
                                        <div class="media-body response-text-right">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit,There are many variations of passages of Lorem Ipsum available,
                                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                            <ul>
                                                <li>DEC 25, 2014</li>
                                                <li><a href="<?php echo e(route('single-view')); ?>">Reply</a></li>
                                            </ul>
                                        </div>
                                        <div class="clearfix"> </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
        </div>
        <div class="side-bar-articles">
            <div class="side-bar-article">
                <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/sai.jpg" alt="" /></a>
                <div class="side-bar-article-title">
                    <a href="<?php echo e(route('single-view')); ?>">Contrary to popular belief, Lorem Ipsum is not simply random text</a>
                </div>
            </div>
            <div class="side-bar-article">
                <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/sai2.jpg" alt="" /></a>
                <div class="side-bar-article-title">
                    <a href="<?php echo e(route('single-view')); ?>">There are many variations of passages of Lorem</a>
                </div>
            </div>
            <div class="side-bar-article">
                <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/sai3.jpg" alt="" /></a>
                <div class="side-bar-article-title">
                    <a href="<?php echo e(route('single-view')); ?>">Sed ut perspiciatis unde omnis iste natus error sit voluptatem</a>
                </div>
            </div>
        </div>
    </div>
    <div class="secound_half">
        <div class="tags">
            <header>
                <h3 class="title-head">Tags</h3>
            </header>
            <p>
                <a class="tag1" href="<?php echo e(route('single-view')); ?>">At vero eos</a>
                <a class="tag2" href="<?php echo e(route('single-view')); ?>">doloremque</a>
                <a class="tag3" href="<?php echo e(route('single-view')); ?>">On the other</a>
                <a class="tag4" href="<?php echo e(route('single-view')); ?>">pain was</a>
                <a class="tag5" href="<?php echo e(route('single-view')); ?>">rationally encounter</a>
                <a class="tag6" href="<?php echo e(route('single-view')); ?>">praesentium voluptatum</a>
                <a class="tag7" href="<?php echo e(route('single-view')); ?>">est, omnis</a>
                <a class="tag8" href="<?php echo e(route('single-view')); ?>">who are so beguiled</a>
                <a class="tag9" href="<?php echo e(route('single-view')); ?>">when nothing</a>
                <a class="tag10" href="<?php echo e(route('single-view')); ?>">owing to the</a>
                <a class="tag11" href="<?php echo e(route('single-view')); ?>">pains to avoid</a>
                <a class="tag12" href="<?php echo e(route('single-view')); ?>">tempora incidunt</a>
                <a class="tag13" href="<?php echo e(route('single-view')); ?>">pursues or desires</a>
                <a class="tag14" href="<?php echo e(route('single-view')); ?>">Bonorum et</a>
                <a class="tag15" href="<?php echo e(route('single-view')); ?>">written by Cicero</a>
                <a class="tag16" href="<?php echo e(route('single-view')); ?>">Ipsum passage</a>
                <a class="tag17" href="<?php echo e(route('single-view')); ?>">exercitationem ullam</a>
                <a class="tag18" href="<?php echo e(route('single-view')); ?>">mistaken idea</a>
                <a class="tag19" href="<?php echo e(route('single-view')); ?>">ducimus qui</a>
                <a class="tag20" href="<?php echo e(route('single-view')); ?>">holds in these</a>
            </p>
        </div>
        <div class="popular-news">
            <header>
                <h3 class="title-popular">popular News</h3>
            </header>
            <div class="popular-grids">
                <div class="popular-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/popular-4.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader will be distracted</a>
                    <p>On Aug 31, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>250 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>68</a></p>
                </div>
                <div class="popular-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/popular-1.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader will be distracted</a>
                    <p>On Mar 14, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>250 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>68</a></p>
                </div>
                <div class="popular-grid">
                    <iframe width="100%" src="https://www.youtube.com/embed/LGMn_yi_62k" frameborder="0" allowfullscreen></iframe>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">Aishwarya Rai Bachchan's Latest SHOCKING News For Ex Salman Khan</a>
                    <p>On Mar 14, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>250 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>68</a></p>
                </div>
                <div class="popular-grid">
                    <a href="<?php echo e(route('single-view')); ?>"><img src="<?php echo e(asset('/')); ?>front/images/popular-3.jpg" alt="" /></a>
                    <a class="title" href="<?php echo e(route('single-view')); ?>">It is a long established fact that a reader will be distracted</a>
                    <p>On Mar 14, 2015 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>250 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-thumbs-up"></span>68</a></p>
                </div>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
</div>