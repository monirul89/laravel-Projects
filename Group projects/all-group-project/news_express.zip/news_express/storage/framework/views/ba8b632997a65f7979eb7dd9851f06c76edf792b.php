<div class="wrap">
    <div class="move-text">
        <div class="breaking_news">
            <h2>Breaking News</h2>
        </div>
        <div class="marquee">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="marquee1"><a class="breaking" href="single.html"><?php echo e($news->news_title); ?></a></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
        <script type="text/javascript" src="<?php echo e(asset('/')); ?>front/js/jquery.marquee.min.js"></script>
        <script>
            $('.marquee').marquee({
                duration:14000,
                pauseOnHover: true

            });

            //@ sourceURL=pen.js
        </script>
    </div>
</div>