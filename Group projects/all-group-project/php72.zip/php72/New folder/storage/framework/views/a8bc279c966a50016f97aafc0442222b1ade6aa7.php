

<!--{{--<h1><?php  echo 'Hello World';   ?></h1>--}}-->

<h1><?php echo e("Hello Double curly"); ?></h1>

<h1><?php echo "Hello Double curly"; ?></h1>

<hr/>
<!--
<a href="<?php echo e(url('/new-one')); ?>">Home</a>
<a href="<?php echo e(url('/new-two')); ?>">About</a>


<a href="<?php echo e(URL::to('/new-one')); ?>">Home</a>
<a href="<?php echo e(URL::to('/new-two')); ?>">About</a>

-->
<a href="<?php echo e(route('new-one')); ?>">Home</a>
<a href="<?php echo e(route('new-two')); ?>">About</a>

<br/>
<h1><?php echo e($name); ?></h1>
<h1><?php echo e($age); ?></h1>
