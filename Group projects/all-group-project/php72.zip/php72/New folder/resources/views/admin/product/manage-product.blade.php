@extends('admin.master')

@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Manage Product</h4>
                </div>
                <div class="panel-body">

                    <h3>{{ Session::get('massage' )}}</h3>

                    <table class="table table-bordered">
                        <tr class="bg-primary">
                            <th>SL No</th>
                            <th>Category Name</th>
                            <th>Brand Name</th>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Product Image</th>
                            <th>Publication Status</th>
                            <th>Action</th>
                        </tr>
                        @php($i=1)
                        @foreach($producs as $product)

                            <tr class="text-center">
                                <td>{{ $i++ }}</td>
                                <td>{{$product->category_name}}</td>
                                <td>{{$product->brand_name}}</td>
                                <td>{{$product->product_name}}</td>
                                <td>{{$product->product_price}}</td>
                                <td><img src="{{asset($product->product_image)}}" width="100" height="100" alt=""></td>
                                <td>{{$product->publicaion_status == 1 ? 'Published' : 'Unpublished'}}</td>
                                <td class="text-center">
                                    <a href="{{route('view-product',['id'=>$product->id])}}" class="btn btn-info
                                    btn-xs"
                                       title="View
                                    Product">
                                        <span class="glyphicon glyphicon-zoom-in"></span>
                                    </a>
                                    <a href="" class="btn btn-info btn-xs">
                                        <span class="glyphicon glyphicon-arrow-up"></span>
                                    </a>

                                    <a class="btn btn-success btn-xs" href="">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>
                                    <a class="btn btn-danger btn-xs" href="" onclick="return confirm('Are you sure to delete this !!')">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>

                                </td>

                            </tr>

                        @endforeach
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection