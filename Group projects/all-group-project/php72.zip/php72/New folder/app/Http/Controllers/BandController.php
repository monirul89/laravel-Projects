<?php

namespace App\Http\Controllers;

use App\Band;
use Illuminate\Http\Request;

class BandController extends Controller
{
    public function index(){
        return view('admin.bands.add-band');
    }
//    public function saveBand(Request $request){
//        $band = new Band();
//        $band->brand_name = $request->brand_name;
//        $band->brand_description = $request->brand_description;
//        $band->published_status = $request->published_status;
//        $band->save();
//
//        return redirect('/band/add')->with('message','Band one data saved');
//    }
    public function saveBand(Request $request){
       $this->validate($request,[
           'brand_name' => 'required|regex:/^[\pL\s\-]+$/u|min:2|max:20',
           'brand_description'=> 'required|min:10|max:50',
           'published_status'=> 'required'
       ]);
    }


    public function manageBand(){

        $bands = Band::all();
        return view('admin.bands.manage-band',['bands'=>$bands]);
    }

   public function unpublishedBand($id){
    $bands = Band::find($id);
    $bands->published_status = 0;
    $bands->save();
    return redirect('/band/manage')->with('message','Band Unpublished');
    }

    public function publishedBand($id){
    $bands = Band::find($id);
    $bands->published_status = 1;
    $bands->save();
    return redirect('/band/manage')->with('message','Band published');
    }

    public function editBand($id){
    $bands = Band::find($id);
    return view('admin.bands.edit-band',['bands'=>$bands]);
    }

    public function updateBand(Request $request){
    $band = Band::find($request->brand_id);
    $band->brand_name = $request->brand_name;
    $band->brand_description = $request->brand_description;
    $band->published_status = $request->published_status;
    $band->save();

    return redirect('/band/manage')->with('message','Band Updated');
    }
    public function deleteBand($id){
    $band = Band::find($id);
    $band->delete();

    return redirect('/band/manage')->with('message','Band deleted');
    }

}
