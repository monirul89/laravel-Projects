<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;
use DB;
class CategoryController extends Controller
{
    public function index(){
        return view('admin.categorys.add-category');
    }

    public function saveCategory(Request $request){
        $category = new Category();
        $category->category_name = $request->category_name;
        $category->category_description = $request->category_description;
        $category->publicaion_status = $request->publicaion_status;
        $category->save();
//        Category::create($request->all());
//        DB::table('categories')->insert([
//            'category_name' => $request->category_name,
//            'category_description' => $request->category_description,
//            'publicaion_status' => $request->publicaion_status
//        ]);
        return redirect('/categorys/add')->with('massage','Category info save successfully');
    }

    public function manageCategory(){
        $categories = Category::all();
      return view('admin.categorys.manage-category',['categories'=>$categories]);
    }

    public function unpublishedCategory($id){
       $category = Category::find($id);
       $category->publicaion_status = 0;
       $category->save();
       return redirect('/categorys/manage')->with('message','Category Unpublished');
    }

    public function publishedCategory($id){
        $category = Category::find($id);
        $category->publicaion_status = 1;
        $category->save();
        return redirect('/categorys/manage')->with('message','Category Published');
    }
    public function editCategory($id){
        $category = Category::find($id);
        return view('admin.categorys.edit-category',['category'=>$category]);
    }
    public function updateCategory(Request $request){

        $category = Category::find($request->category_id);

        $category->category_name = $request->category_name;
        $category->category_description = $request->category_description;
        $category->publicaion_status = $request->publicaion_status;
        $category->save();
        return redirect('/categorys/manage')->with('massage','Category Updated');
    }

    public function deleteCategory($id){
        $category = Category::find($id);
        $category->delete();
        return redirect('/categorys/manage')->with('massage','Category delete');
    }

}
