<?php

namespace App\Http\Controllers;

use App\Band;
use App\Category;
use App\Product;

use Faker\Provider\Image;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ProductController extends Controller
{
    public function index(){
        $catagories = Category::where('publicaion_status',1)->get();
        $brands = Band::Where('published_status',1)->get();
        return view('admin.product.add-product',['catagories' => $catagories, 'brands'=>$brands]);
    }
    public function manageProducts(){
        $producs = DB::table('products')
        ->join('categories','products.category_id', '=', 'categories.id')
        ->join('bands','products.brand_id', '=', 'bands.id')
        ->select('products.*', 'categories.category_name', 'bands.brand_name')
        ->get();

        return view('admin.product.manage-product',['producs'=>$producs]);
    }
    public function pupupProducts(){
        return view('admin.product.pupup');
    }

    public function saveProducts(Request $request){
        $this->validate($request,[
           'product_name'=>'required'
        ]);
//        $productImage = $request->file('product_image');
//        $imageName = $productImage->getClientOriginalName();
//        $directory = 'product-images/';
//        $imageUrl = $directory.$imageName;
//        $productImage->move($directory, $imageName);



        $productImage = $request->file('product_image');
        $imageName = $productImage->getClientOriginalName();
        $directory = 'product-images/';
        $imageUrl = $directory.$imageName;
        Image::make($productImage)->save($imageUrl);


        $product = new Product();
        $product->category_id = $request->category_id;
        $product->brand_id = $request->brand_id;
        $product->product_name = $request->product_name;
        $product->product_price = $request->product_price;
        $product->product_quentity = $request->product_quentity;
        $product->short_description = $request->short_description;
        $product->long_description = $request->long_description;
        $product->product_image = $imageUrl;
        $product->publicaion_status = $request->publicaion_status;
        $product->save();

        return redirect('/products/add')->with('message','Save Successful');

    }
    public function viewProductProducts($id){
        $product = Product::find($id);
        redirect('admin.product.view-product',['product'=>$product]);
    }

}
