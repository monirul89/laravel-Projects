<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Manage Product</h4>
                </div>
                <div class="panel-body">

                    <h3><?php echo e(Session::get('massage' )); ?></h3>

                    <table class="table table-bordered">
                        <tr class="bg-primary">
                            <th>SL No</th>
                            <th>Category Name</th>
                            <th>Brand Name</th>
                            <th>Product Name</th>
                            <th>Product Price</th>
                            <th>Product Image</th>
                            <th>Publication Status</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $producs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr class="text-center">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($product->category_name); ?></td>
                                <td><?php echo e($product->brand_name); ?></td>
                                <td><?php echo e($product->product_name); ?></td>
                                <td><?php echo e($product->product_price); ?></td>
                                <td><img src="<?php echo e(asset($product->product_image)); ?>" width="100" height="100" alt=""></td>
                                <td><?php echo e($product->publicaion_status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('view-product',['id'=>$product->id])); ?>" class="btn btn-info
                                    btn-xs"
                                       title="View
                                    Product">
                                        <span class="glyphicon glyphicon-zoom-in"></span>
                                    </a>
                                    <a href="" class="btn btn-info btn-xs">
                                        <span class="glyphicon glyphicon-arrow-up"></span>
                                    </a>

                                    <a class="btn btn-success btn-xs" href="">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>
                                    <a class="btn btn-danger btn-xs" href="" onclick="return confirm('Are you sure to delete this !!')">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>