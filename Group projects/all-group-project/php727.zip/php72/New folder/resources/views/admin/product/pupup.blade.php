
@extends('admin.master')

@section('body')
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Add Band Form</h4>
                </div>
                <div class="panel-body">
                    <h2>{{Session::get('message')}}</h2>
                </div>
            </div>
        </div>
    </div>
@endsection