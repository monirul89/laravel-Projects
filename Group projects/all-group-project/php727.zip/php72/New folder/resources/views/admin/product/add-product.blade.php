@extends('admin.master')

@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Add Product Form</h4>
                </div>
                <div class="panel-body">
                    <h3></h3>
                        {{Form::open(['route'=>'save-product', 'method'=>'POST', 'class'=>'form-horizontal',
                        'enctype'=>'multipart/form-data'])}}
                    <h3>{{Session::get('message')}}</h3>

                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Category Name</label>
                            <div class="form-group col-md-8">
                                <select placeholder="Category Name" type="text" name="category_id" class="form-control">
                                    <option value="">---Select Category---</option>
                                    @foreach($catagories as $catagory)

                                    <option value="{{$catagory->id}}">{{$catagory->category_name}}</option>

                                    @endforeach

                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Brand Name</label>
                            <div class="form-group col-md-8">
                                <select placeholder="Brand Name" type="text" name="brand_id" class="form-control">
                                    <option value="">---Select Brand---</option>
                                    @foreach($brands as $brand)
                                    <option value="{{$brand->id}}">{{$brand->	brand_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Product Name</label>
                            <div class="form-group col-md-8">
                        <input placeholder="Product Name" type="text" name="product_name" class="form-control" />
                                <span class="text-danger">{{$errors->has('product_name') ? $errors->first('product_name') : ''}}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Product Price</label>
                            <div class="form-group col-md-8">
                                <input placeholder="Product Pric" type="number" name="product_price"
                                       class="form-control" />
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Product Quentity</label>
                            <div class="form-group col-md-8">
                                <input placeholder="Product Quentity" type="number" name="product_quentity"
                                       class="form-control" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Short Description</label>
                            <div class="form-group col-md-8">
                    <textarea placeholder="Short Description" type="text" name="short_description"
                              class="form-control" /></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Long Description</label>
                            <div class="form-group col-md-8">
                    <textarea placeholder="Long Description" id="editor" type="text" name="long_description"
                              class="form-control" /></textarea>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Product Image</label>
                            <div class="form-group col-md-8">
                                <input type="file" class="" name="product_image" accept="image/*">
                                <span class="text-danger">{{$errors->has('product_image') ? $errors->first('product_image') : ''}}</span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Publication Status</label>
                            <div class="col-md-8 radio">
                                <label for=""><input type="radio" checked name="publicaion_status" value="1"
                                    />Published</label>
                                <label for=""><input type="radio" name="publicaion_status" value="0"
                                    />Unpublished</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <input type="submit" name="btn" class="btn btn-success btn-block" value="Save
                                Product Info" />
                            </div>
                        </div>

                        {{Form::close()}}

                </div>
            </div>
        </div>
    </div>
@endsection