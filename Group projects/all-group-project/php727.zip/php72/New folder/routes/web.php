<?php

Route::get('/',[
    'uses' => 'BigStoreController@index',
    'as' => '/'
]);
Route::get('/contact-us',[
    'uses' => 'BigStoreController@contactUs',
    'as' => 'contact'
]);

Route::get('/hair-care',[
    'uses'=>'BigStoreController@hairCare',
    'as'=>'care'
]);
Route::get('/care/single',[
    'uses'=>'BigStoreController@singleProduct',
    'as'=>'single'
]);

//Seip--ADB

Route::get('/categorys/add',[
    'uses'=>'CategoryController@index',
    'as'=>'add-categorys'
]);
Route::get('/categorys/manage',[
    'uses'=>'CategoryController@manageCategory',
    'as'=>'manage-category'
]);

Route::post('/categorys/save',[
    'uses'=>'CategoryController@saveCategory',
    'as'=>'new-category'
]);
Route::get('/categorys/unpublished/{id}',[
    'uses'=>'CategoryController@unpublishedCategory',
    'as'=>'unpublished-category'
]);
Route::get('/categorys/published/{id}',[
    'uses'=>'CategoryController@publishedCategory',
    'as'=>'published-category'
]);
Route::get('/categorys/edit{id}',[
    'uses'=>'CategoryController@editCategory',
    'as'=>'edit-category'
]);
Route::post('/categorys/update',[
    'uses'=>'CategoryController@updateCategory',
    'as'=>'update-category'
]);
Route::get('/categorys/delete/{id}',[
    'uses'=>'CategoryController@deleteCategory',
    'as'=>'delete-category'
]);

Route::get('/band/add',[
    'uses'=>'BandController@index',
    'as'=>'add-band'
]);
//Route::post('/band/save',[
//    'uses'=>'BandController@saveBand',
//    'as'=>'save-band'
//]);
Route::post('/band/save',[
    'uses'=>'BandController@saveBand',
    'as'=>'save-band'
]);


Route::get('/band/manage',[
    'uses'=>'BandController@manageBand',
    'as'=>'manage-band'
]);
Route::get('/band/unpublished/{id}',[
    'uses'=>'BandController@unpublishedBand',
    'as'=>'unpublished-band'
]);
Route::get('/band/published/{id}',[
    'uses'=>'BandController@publishedBand',
    'as'=>'published-band'
]);
Route::get('/band/edit/{id}',[
    'uses'=>'BandController@editBand',
    'as'=>'edit-band'
]);

Route::post('/band/update',[
    'uses'=>'BandController@updateBand',
    'as'=>'update-band'
]);
Route::get('/band/delete/{id}',[
    'uses'=>'BandController@deleteBand',
    'as'=>'delete-band'
]);

Route::get('/products/add',[
    'uses'=>'ProductController@index',
    'as'=>'add-products'
]);
Route::post('/products/save',[
    'uses'=>'ProductController@saveProducts',
    'as'=>'save-product'
]);

Route::get('/products/manage',[
    'uses'=>'ProductController@manageProducts',
    'as'=>'manage-products'
]);

Route::get('/products/pupup',[
    'uses'=>'ProductController@pupupProducts',
    'as'=>'/'
]);
Route::get('/product/view/{id}',[
    'uses'=>'ProductController@viewProductProducts',
    'as'=>'view-product'
]);








Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
