<!DOCTYPE html>
<html lang="en">
<head>
    <!--===============================================
    Template Design By WpFreeware Team.
    Author URI : http://www.wpfreeware.com/
    ====================================================-->

    <!-- Basic Page Needs
    ================================================== -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Mobile Specific Metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="<?php echo e(asset('/')); ?>front/img/wpf-favicon.png"/>

    <!-- CSS
    ================================================== -->
    <!-- Bootstrap css file-->
    <link href="<?php echo e(asset('/')); ?>front/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font awesome css file-->
    <link href="<?php echo e(asset('/')); ?>front/css/font-awesome.min.css" rel="stylesheet">
    <!-- Superslide css file-->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>front/css/superslides.css">
    <!-- Slick slider css file -->
    <link href="<?php echo e(asset('/')); ?>front/css/slick.css" rel="stylesheet">
    <!-- Circle counter cdn css file -->
    <link rel='stylesheet prefetch' href="<?php echo e(asset('/')); ?>front/css/jquery.circliful.css">
    <!-- smooth animate css file -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>front/css/animate.css">
    <!-- preloader -->
    <link rel="stylesheet" href="<?php echo e(asset('/')); ?>front/css/queryLoader.css" type="text/css" />
    <!-- gallery slider css -->
    <link type="text/css" media="all" rel="stylesheet" href="<?php echo e(asset('/')); ?>front/css/jquery.tosrus.all.css" />
    <!-- Default Theme css file -->
    <link id="switcher" href="<?php echo e(asset('/')); ?>front/css/themes/default-theme.css" rel="stylesheet">
    <!-- Main structure css file -->
    <link href="<?php echo e(asset('/')); ?>front/css/style.css" rel="stylesheet">

    <!-- Google fonts -->
    <link href='http://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Varela' rel='stylesheet' type='text/css'>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>

<!-- SCROLL TOP BUTTON -->
<a class="scrollToTop" href="#"></a>
<!-- END SCROLL TOP BUTTON -->

<!--=========== BEGIN HEADER SECTION ================-->
<?php echo $__env->make('front-end.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->yieldContent('banner'); ?>


<?php echo $__env->yieldContent('body'); ?>

<!--=========== BEGIN FOOTER SECTION ================-->
<?php echo $__env->make('front-end.includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--=========== END FOOTER SECTION ================-->



<!-- Javascript Files
================================================== -->

<!-- initialize jQuery Library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<!-- Preloader js file -->
<script src="<?php echo e(asset('/')); ?>front/js/queryloader2.min.js" type="text/javascript"></script>
<!-- For smooth animatin  -->
<script src="<?php echo e(asset('/')); ?>front/js/wow.min.js"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('/')); ?>front/js/bootstrap.min.js"></script>
<!-- slick slider -->
<script src="<?php echo e(asset('/')); ?>front/js/slick.min.js"></script>
<!-- superslides slider -->
<script src="<?php echo e(asset('/')); ?>front/js/jquery.easing.1.3.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/jquery.animate-enhanced.min.js"></script>
<script src="<?php echo e(asset('/')); ?>front/js/jquery.superslides.min.js" type="text/javascript" charset="utf-8"></script>
<!-- for circle counter -->
<script src="<?php echo e(asset('/')); ?>front/js/jquery.circliful.min.js"></script>
<!-- Gallery slider -->
<script type="text/javascript" language="javascript" src="<?php echo e(asset('/')); ?>front/js/jquery.tosrus.min.all.js"></script>

<!-- Custom js-->
<script src="<?php echo e(asset('/')); ?>front/js/custom.js"></script>
<!--===============================================
Template Design By WpFreeware Team.
Author URI : http://www.wpfreeware.com/
====================================================-->


</body>
</html>