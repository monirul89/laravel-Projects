<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-primary">Add Student Form</h4>
                </div>
                <div class="panel-body">
                    <h5 class="text-success text-center mb-4"> <?php echo e(Session::get('message')); ?> </h5>
                    <?php echo e(Form::open(['route'=>'save-student', 'method'=>'POST', 'class'=>'form-horizontal', 'enctype'=>'multipart/form-data'])); ?>

                    <div class="form-group">
                        <label class="control-label col-md-4">Student Name</label>
                        <div class="form-group col-md-8">
                            <input type="text" name="student_name" class="form-control" />
                            <span class="text-danger"><?php echo e($errors->has('student_name') ? $errors->first('student_name') : ' '); ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Student Department</label>
                        <div class="form-group col-md-8">
                            <select name="department_id" class="form-control">
                                <option value=" ">--- Select Student Department ---</option>
                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->id); ?>"><?php echo e($department->department_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php echo e($errors->has('department_id') ? $errors->first('department_id', 'Department name is required') : ' '); ?></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Student Status</label>
                        <div class="form-group col-md-8">
                            <select name="student_status_id" class="form-control">
                                <option value=" ">--- Select Student Status ---</option>
                                <?php $__currentLoopData = $studentStatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($studentStatus->id); ?>"><?php echo e($studentStatus->student_status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="text-danger"><?php echo e($errors->has('student_status_id') ? $errors->first('student_status_id', 'Student status is required') : ' '); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4">Student's Comment</label>
                        <div class="form-group col-md-8">
                            <textarea name="students_comment" class="form-control"></textarea>
                            <span class="text-danger"><?php echo e($errors->has('students_comment') ? $errors->first('students_comment') : ' '); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4">Student Image</label>
                        <div class="form-group col-md-8">
                            <input type="file" name="student_image" accept="image/*" class="form-control" />
                            <span class="text-danger"><?php echo e($errors->has('student_image') ? $errors->first('student_image') : ' '); ?></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4">Publication Status</label>
                        <div class="form-group col-md-8">
                            <label> <input type="radio" name="publication_status" checked value="1" />Published</label>
                            <label> <input type="radio" name="publication_status" value="0" />Unpublished</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="Save Student Info" />
                        </div>
                    </div>

                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>