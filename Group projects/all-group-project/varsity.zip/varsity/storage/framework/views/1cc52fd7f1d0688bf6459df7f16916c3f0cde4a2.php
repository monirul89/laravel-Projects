<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-primary">Manage Department Info</h4>
                </div>
                <div class="panel-body">
                    <h4 class="text-success text-center mb-4"> <?php echo e(Session::get('message')); ?> </h4>
                    <table class="table table-bordered">
                        <tr class="bg-info">
                            <th>SL No</th>
                            <th>department Name</th>
                            <th>Department Description</th>
                            <th>Publication Status</th>
                            <th width="130">Action</th>
                        </tr>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($department->department_name); ?> </td>
                                <td><?php echo e($department->department_description); ?> </td>
                                <td> <?php echo e($department->publication_status == 1 ? 'Published' : 'Unpublished'); ?> </td>
                                <td>
                                    <?php if($department->publication_status == 1): ?>
                                        <a href="<?php echo e(route('unpublished-department', ['id'=> $department->id])); ?>" class="btn btn-info btn-xs">
                                            <span class="glyphicon glyphicon-arrow-up"></span>
                                        </a>
                                    <?php else: ?>

                                        <a href="<?php echo e(route('published-department', ['id'=> $department->id])); ?>" class="btn btn-warning btn-xs">
                                            <span class="glyphicon glyphicon-arrow-down"></span>
                                        </a>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route('edit-department',['id'=>$department->id])); ?>" class="btn btn-primary btn-xs">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>

                                    <a href="<?php echo e(route('delete-department', ['id'=> $department->id])); ?>" class="btn btn-danger btn-xs" onclick="return confirm('Do you want to Delete this Department??')" >
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>