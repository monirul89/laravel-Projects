<?php $__env->startSection('title'); ?>
    Gallery
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    <section id="imgBanner">
        <h2>Gallery</h2>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section id="gallery">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div id="gallerySLide" class="gallery_area">
                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(asset($gallery->gallery_image)); ?>" title="<?php echo e($gallery->gallery_title); ?>">
                            <img class="gallery_img" src="<?php echo e(asset($gallery->gallery_image)); ?>" alt="img" />
                            <span class="view_btn">View</span>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php echo e($galleries->links()); ?>

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>