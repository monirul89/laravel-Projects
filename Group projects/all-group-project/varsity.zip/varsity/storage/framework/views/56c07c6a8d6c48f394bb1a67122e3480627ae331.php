<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-primary">Edit About Form</h4>
                </div>
                <div class="panel-body">
                    <h5 class="text-success text-center mb-4"> <?php echo e(Session::get('message')); ?> </h5>
                    <?php echo e(Form::open(['route'=>'update-about', 'method'=>'POST', 'class'=>'form-horizontal', 'enctype'=>'multipart/form-data'])); ?>


                    <div class="form-group">
                        <label class="control-label col-md-4">About Us</label>
                        <div class="form-group col-md-8">
                            <textarea id="editor" name="about_us" class="form-control"><?php echo e($about->about_us); ?></textarea>
                            <input type="hidden" name="about_id" class="form-control" value="<?php echo e($about->id); ?>"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Publication Status</label>
                        <div class="form-group col-md-8">
                            <label> <input type="radio" name="publication_status" value="1" <?php echo e($about->publication_status == 1 ? 'checked' : ' '); ?> />Published</label> &nbsp;&nbsp;
                            <label> <input type="radio" name="publication_status" value="0" <?php echo e($about->publication_status == 0 ? 'checked' : ' '); ?> />Unpublished</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="Update About Info" />
                        </div>
                    </div>

                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>