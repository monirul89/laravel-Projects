<?php $__env->startSection('title'); ?>
    Course Archive
<?php $__env->stopSection(); ?>

<?php $__env->startSection('banner'); ?>
    <section id="imgBanner">
        <h2>Course Archive</h2>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section id="courseArchive">
        <div class="container">
            <div class="row">
                <!-- start course content -->
                <div class="col-lg-8 col-md-8 col-sm-8">
                    <div class="courseArchive_content">
                        <div class="row">
                            <!-- start single course -->
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <div class="single_course wow fadeInUp">
                                    <div class="singCourse_imgarea">
                                        <img src="<?php echo e(asset($course->course_image)); ?>" height="230px;" />
                                        <div class="mask">
                                            <a href="<?php echo e(route('course-single', ['id'=>$course->id])); ?>" class="course_more">View Course</a>
                                        </div>
                                    </div>
                                    <div class="singCourse_content">
                                        <h3 class="singCourse_title"><a href="<?php echo e(route('course-single', ['id'=>$course->id])); ?>"><?php echo e($course->course_title); ?></a></h3>
                                        <p class="singCourse_price">TK. <span><?php echo e($course->course_price); ?></span> Per Credit Hour</p>
                                        <p><?php echo e($course->short_description); ?></p>
                                    </div>
                                    <div class="singCourse_author">
                                        <img src="<?php echo e(asset($course->teacher_image)); ?>" alt="img">
                                        <p><?php echo e($course->teacher_name); ?>, Teacher</p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- End single course -->
                        </div>
                        <?php echo e($courses->links()); ?>

                    </div>
                </div>
                <!-- End course content -->

                <!-- start course archive sidebar -->
                <div class="col-lg-4 col-md-4 col-sm-4">
                    <div class="courseArchive_sidebar">
                        <!-- start single sidebar -->
                        <div class="single_sidebar">
                            <h2>Events <span class="fa fa-angle-double-right"></span></h2>
                            <ul class="news_tab">
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <div class="media">
                                            <div class="media-left">
                                                <a class="news_img" href="<?php echo e(route('event-single', ['id'=>$event->id])); ?>">
                                                    <img class="media-object" src="<?php echo e(asset($event->event_image)); ?>" alt="img">
                                                </a>
                                            </div>
                                            <div class="media-body">
                                                <a href="<?php echo e(route('event-single', ['id'=>$event->id])); ?>"><?php echo e($event->event_name); ?></a>
                                                <span class="feed_date"><?php echo e($event->event_date); ?></span>
                                            </div>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <!-- End single sidebar -->

                        <!-- start single sidebar -->
                        <div class="single_sidebar">
                            <h2>Sponsor Add <span class="fa fa-angle-double-right"></span></h2>
                            <a class="side_add" href="#"><img src="<?php echo e(asset('/')); ?>front/img/side-add.jpg" alt="img"></a>
                        </div>
                        <!-- End single sidebar -->
                    </div>
                </div>
                <!-- start course archive sidebar -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>