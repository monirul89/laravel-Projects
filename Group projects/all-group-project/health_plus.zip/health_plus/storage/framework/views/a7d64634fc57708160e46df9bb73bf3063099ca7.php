<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-primary">Add Menu Info</h4>
                </div>
                <div class="panel-body">
                    <h4 class="text-success text-center mb-4"> <?php echo e(Session::get('message')); ?> </h4>
                    <?php echo Form::open(['route'=>'save-menu', 'method'=>'POST', 'class'=>'form-horizontal']); ?>

                    <div class="form-group">
                        <label class="control-label col-md-4">Menu Name</label>
                        <div class="form-group col-md-8">
                            <input type="text" name="menu_name" class="form-control" />
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4">Menu Description</label>
                        <div class="form-group col-md-8">
                            <textarea class="form-control" name="menu_description" rows="4"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Publication Status</label>
                        <div class="form-group col-md-8">
                            <label> <input type="radio" name="publication_status" checked value="1" />Published</label> &nbsp;&nbsp;
                            <label> <input type="radio" name="publication_status" value="0" />Unpublished</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="SAVE CATEGORY INFO" />
                        </div>
                    </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>