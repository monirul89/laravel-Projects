<?php $__env->startSection('title'); ?>
   Departments
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="banner1 jarallax">
        <div class="container">
        </div>
    </div>
    <!-- //banner1 -->



    <div class="agile_menu" id="menu">
        <div class="container">

            <h3 class="w3_heade_tittle_agile" >Our Departments</h3>
            <br/>
            <div class="menu_w3ls_agile_top_section">
                <div class="ziehharmonika">
                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h3><?php echo e($department->department_name); ?></h3>
                    <div>
                        <div class="w3_agile_recipe-grid">

                            <div class="col-md-6 col-sm-6 tab-image">
                                <img src="<?php echo e(asset($department->department_image)); ?>" alt="Medicinal">
                            </div>
                            <div class="col-md-6 col-sm-6 tab-info">
                                <h4><?php echo e($department->department_title); ?></h4>
                                <p><?php echo $department->department_description; ?> </p>
                            </div>
                            <div class="clearfix"></div>
                        </div>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
    </div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>