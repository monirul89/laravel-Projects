<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="banner-silder">
        <div id="JiSlider" class="jislider">
            <ul>
                <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="w3layouts-banner-top">

                        <div class="container">
                            <div class="agileits-banner-info">
                                <img src="<?php echo e(asset($slider->slider_image)); ?>"/>
                                <span><?php echo e($slider->slider_sort_title); ?></span>
                                <h3><?php echo e($slider->slider_title); ?> </h3>
                                <p><?php echo $slider->slider_description; ?></p>

                            </div>
                        </div>
                    </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </ul>
        </div>
    </div>

    <!-- //banner -->

    <!-- about -->
    <div class="about" id="about">
        <div class="container">
            <h2 class="w3_heade_tittle_agile"><?php echo e($welcome->welcome_title); ?></h2>

            <p class="ab"><?php echo $welcome->welcome_description; ?></p>
        </div>
    </div>
    <!-- /about-bottom -->
    <!-- /girds_agileits -->
    <div class="Department_girds_agileits">
        <div class="agile_team_grid">
            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-md-3 w3ls_banner_bottom_grid">
                <img src="<?php echo e(asset($department->department_image)); ?>" alt=" " class="img-responsive" />
                <div class="overlay">
                    <h4><?php echo e($department->department_name); ?></h4>

                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="clearfix"></div>
    </div>
    <!-- //girds_agileits -->



    <!-- stats -->
    <div class="stats" id="stats">
        <div class="container">
            <div class="inner_w3l_agile_grids">
                <div class="col-md-3 w3layouts_stats_left w3_counter_grid">
                    <i class="fa fa-building-o" aria-hidden="true"></i>
                    <p class="counter">120</p>
                    <h3>Hospital Rooms</h3>
                </div>
                <div class="col-md-3 w3layouts_stats_left w3_counter_grid1">
                    <i class="fa fa-wheelchair" aria-hidden="true"></i>
                    <p class="counter">165</p>
                    <h3>Wheelchair</h3>
                </div>
                <div class="col-md-3 w3layouts_stats_left w3_counter_grid2">
                    <i class="fa fa-ambulance" aria-hidden="true"></i>
                    <p class="counter">563</p>
                    <h3>Ambulance Car</h3>
                </div>
                <div class="col-md-3 w3layouts_stats_left w3_counter_grid3">
                    <i class="fa fa-heart-o" aria-hidden="true"></i>
                    <p class="counter">245</p>
                    <h3>Saved Hearts</h3>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
    <!-- //stats -->

    <!-- services-bottom -->
    <div class="services-bottom">
        <div class="col-md-6 wthree_services_bottom_right">
            <section class="slider">
                <div class="flexslider">
                    <ul class="slides">
                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <div class="w3_agile_services_bottom_right_grid">
                                <p class="w3layouts_head_slide"><?php echo e($department->department_name); ?></p>

                            </div>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </section>
        </div>

        <div class="col-md-6 wthree_services_bottom_left">
            <div class="wthree_services_bottom_left_grid">
                <section class="slider">
                    <div class="flexslider">
                        <ul class="slides">
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="col-md-12 w3_agileits_services_bottom_r_grid">
                                        <h4><?php echo e($department->department_title); ?></h4>
                                        <p><?php echo $department->department_description; ?></p>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </section>


                <div class="clearfix"> </div>
            </div>

        </div>


        <div class="clearfix"> </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>