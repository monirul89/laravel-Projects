<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-primary">View About Info</h4>
                </div>
                <div class="panel-body">
                    <h4 class="text-success text-center mb-4"> <?php echo e(Session::get('message')); ?> </h4>

                    <table class="table table-bordered">
                        <tr>
                            <th>About Id</th>
                            <td><?php echo e($about->id); ?></td>
                        </tr>

                        <tr>
                            <th>About Name</th>
                            <td><?php echo e($about->about_name); ?></td>
                        </tr>

                        <tr>
                            <th>About Image</th>
                            <td> <img src="<?php echo e(asset($about->about_image)); ?>" alt=" " height="120" width="120" /> </td>
                        </tr>

                        <tr>
                            <th>About Description</th>
                            <td><?php echo $about->about_description; ?></td>
                        </tr>

                    </table>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>