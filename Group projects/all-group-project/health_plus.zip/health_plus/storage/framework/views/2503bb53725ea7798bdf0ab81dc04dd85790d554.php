<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Edit Menu Info</h4>
                </div>
                <div class="panel-body">
                    <?php echo e(Form::open(['route'=>'update-menu', 'method'=>'POST', 'class'=>'form-horizontal', 'enctype'=>'multipart/form-data'])); ?>

                    <div class="form-group">
                        <label class="control-label col-md-4">Menu Name</label>
                        <div class="col-md-8">
                            <input type="text" value="<?php echo e($menu->menu_name); ?>" name="menu_name" class="form-control"/>
                            <input type="hidden" value="<?php echo e($menu->id); ?>" name="menu_id" class="form-control"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-4">Menu Description</label>
                        <div class="col-md-8">
                            <textarea name="menu_description" class="form-control"><?php echo e($menu->menu_description); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-md-4">Publication Status</label>
                        <div class="col-md-8 radio">
                            <label><input type="radio" checked name="publication_status" value="1" <?php echo e($menu->publication_status == 1 ? 'checked': ' '); ?> />Published</label>
                            <label><input type="radio" name="publication_status" value="0" <?php echo e($menu->publication_status == 0 ? 'checked': ' '); ?> />Unpublished</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-8 col-md-offset-4">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="Save About Info"/>
                        </div>
                    </div>
                    <?php echo e(Form::close()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>