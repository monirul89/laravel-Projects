<?php $__env->startSection('title'); ?>
   Our Team
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <div class="banner1 jarallax">
        <div class="container">
        </div>
    </div>

    <div class="team portfolio " id="team">
        <div class="container">
            <h3 class="w3_heade_tittle_agile">Amazing Team</h3>
            <p class="sub_t_agileits">Meet Our Amazing Team...</p>
            <div class="w3layouts-grids">
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 wthree_team_grid">

                    <div class="wthree_team_grid1">
                        <div class="hover14 column">
                            <div>
                                <figure><img src="<?php echo e(asset($team->doctor_image)); ?>" alt=" " class="img-responsive" /></figure>
                            </div>
                        </div>
                        <div class="wthree_team_grid1_pos">
                            <h3><?php echo e($team->team_title); ?></h3>
                            <h3><?php echo e($team->doctor_name); ?></h3>
                            <h4><?php echo e($team->doctor_speciality); ?></h4>
                            <h5> <?php echo e($team->doctor_consultant); ?> </h5>
                            <h6><?php echo $team->short_description; ?> </h6>
                        </div>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>








<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>