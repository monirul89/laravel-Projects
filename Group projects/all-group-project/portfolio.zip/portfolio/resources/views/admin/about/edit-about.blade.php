@extends('admin.master')

@section('title')
    Edit About
@endsection

@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Edit Home Page Content</h4>
                </div>
                <div class="panel-body">

                    {{ Form::open(['route'=>'about-update', 'class'=>'form-horizontal', 'method'=>'POST' ]) }}

                    <div class="form-group">
                        <label for="" class="control-label col-md-2">About Title</label>
                        <div class="form-group col-md-10">
                            <input type="text" value="{{$aboutContent->about_title}}" name="about_title" placeholder="About Title" class="form-control" />
                            <input type="hidden" value="{{$aboutContent->id}}" name="about_id"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="control-label col-md-2">About Content</label>
                        <div class="form-group col-md-10">
                            <textarea name="about_content" class="form-control" id="editor">{{ $aboutContent->about_content }}</textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="control-label col-md-2">Publication Status</label>
                        <div class="col-md-10 radio">
                            <label><input type="radio" {{ $aboutContent->published_status == 1 ? 'checked' : '' }} name="published_status" value="1" />Published</label>
                            <label><input type="radio" {{ $aboutContent->published_status == 0 ? 'checked' : '' }} name="published_status" value="0" />Unublished</label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="" class="control-label col-md-2"></label>
                        <div class="form-group col-md-4">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="Update Content" />
                        </div>
                        <label for="" class="control-label col-md-6"></label>
                    </div>

                    {{ Form::close() }}

                </div>
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
@endsection

