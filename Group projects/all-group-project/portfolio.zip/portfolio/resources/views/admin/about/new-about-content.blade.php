@extends('admin.master')

@section('title')
    About Content
@endsection

@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">About Content</h4>
                </div>
                <div class="panel-body">

                    {{ Form::open(['route'=>'save-about-content', 'class'=>'form-horizontal', 'method'=>'POST' ]) }}
                        <h3 class="text-center text-success">{{ Session::get('message') }}</h3>
                    <div class="form-group">
                        <label for="" class="control-label col-md-2">About Title</label>
                        <div class="form-group col-md-10">
                            <input type="text" value="" name="about_title" placeholder="About Title" class="form-control" />
                            <input type="hidden" value="" name="about_id"/>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="control-label col-md-2">About Content</label>
                        <div class="form-group col-md-10">
                            <textarea name="about_content" class="form-control" id="editor"></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="control-label col-md-2">Publication Status</label>
                        <div class="col-md-10 radio">
                            <label><input type="radio" checked name="published_status" value="1" />Published</label>
                            <label><input type="radio" name="published_status" value="0" />Unublished</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="" class="control-label col-md-2"></label>
                        <div class="form-group col-md-3">
                            <input type="submit" name="btn" class="btn btn-success btn-block" value="Save About Content" />
                        </div>
                        <label for="" class="control-label col-md-7"></label>
                    </div>

                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
@endsection

