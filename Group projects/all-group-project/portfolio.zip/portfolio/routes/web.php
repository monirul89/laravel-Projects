<?php

//Front end

Route::get('/',[
    'uses' => 'portfolioController@index',
    'as' => '/'
]);

Route::get('/admin/home',[
    'uses' => 'portfolioController@adminHome',
    'as' => 'login'
]);


Route::get('/about-us',[
    'uses' => 'portfolioController@aboutUs',
    'as' => 'about-us'
]);

Route::get('/projects',[
    'uses'  => 'portfolioController@projects',
    'as'    => 'projects'
]);

Route::get('/gallery',[
    'uses' => 'portfolioController@gallery',
    'as' => 'gallery'
]);
Route::get('/contact-us',[
    'uses' => 'portfolioController@contactUs',
    'as' => 'contact'
]);


//admin panel page

//home page
Route::get('/add-content',[
    'uses' => 'addContentController@addContent',
    'as' => 'add-content'
]);

Route::post('/save-content',[
    'uses' => 'addContentController@saveContent',
    'as' => 'save-content'
]);

Route::get('/manage/content',[
    'uses' => 'addContentController@manageContent',
    'as' => 'manage-content'
]);

Route::get('/content/unpublished/{id}',[
    'uses' => 'addContentController@unpublishedHomeContent',
    'as' => 'unpublished-home-content'
]);

Route::get('/content/published/{id}',[
    'uses' => 'addContentController@publishedHomeContent',
    'as' => 'published-home-content'
]);

Route::get('/content/edit/vission/{id}',[
    'uses' => 'addContentController@editVissionContent',
    'as' => 'edit-vission'
]);
Route::get('/content/edit/mission/{id}',[
    'uses' => 'addContentController@editMissionContent',
    'as' => 'edit-mission'
]);

Route::get('/content/edit/goal/{id}',[
    'uses' => 'addContentController@editGoalContent',
    'as' => 'edit-goal'
]);

Route::post('/content/goal/update',[
    'uses' => 'addContentController@updateGoalContent',
    'as' => 'goal-update'
]);
Route::post('/content/vission/update',[
    'uses' => 'addContentController@updateVissionContent',
    'as' => 'vission-update'
]);

Route::post('/content/mission/update',[
    'uses' => 'addContentController@updateMissionContent',
    'as' => 'mission-update'
]);
Route::get('/home/content/delete/{id}',[
    'uses' => 'addContentController@deleteHomeContent',
    'as' => 'delete-home-content'
]);

//End of home page

Route::get('/about/content/new',[
    'uses' => 'AboutController@newAboutContent',
    'as' => 'new-about-content'
]);
Route::get('/about/content/manage',[
    'uses' => 'AboutController@manageAboutContent',
    'as' => 'manage-about-content'
]);
Route::post('/about/content/save',[
    'uses' => 'AboutController@saveAboutContent',
    'as' => 'save-about-content'
]);
Route::get('/content/about/unpublished/{id}',[
    'uses' => 'AboutController@unpublishedAboutContent',
    'as' => 'unpublished-about-content'
]);

Route::get('/content/about/published/{id}',[
    'uses' => 'AboutController@publishedAboutContent',
    'as' => 'published-about-content'
]);

Route::get('/about/edit/{id}',[
    'uses' => 'AboutController@editAboutContent',
    'as' => 'edit-about'
]);
Route::post('/about/update/',[
    'uses' => 'AboutController@updateAboutContent',
    'as' => 'about-update'
]);


Route::get('/about/content/delete/{id}',[
    'uses' => 'AboutController@deleteAboutContent',
    'as' => 'delete-about-content'
]);












Auth::routes();

Route::get('/admin/home', 'HomeController@index')->name('home');
