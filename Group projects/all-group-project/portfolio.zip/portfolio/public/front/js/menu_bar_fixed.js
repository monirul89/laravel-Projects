// $(document).ready(function(){
//     $offset = $('#banner').offset().top;
//     //alert($offset);
// });
//
// // includes bar fixed
//
// $(window).scroll(function(){
//     $scrolling = $(this).scrollTop();
//     if ($scrolling >= $offset){
//         $('#includes').removeClass('menu_bar1')
//         $('#includes').addClass('menu_bar2')
//
//     }else{
//         $('#includes').removeClass('menu_bar2')
//         $('#includes').addClass('menu_bar1')
//     }
// });