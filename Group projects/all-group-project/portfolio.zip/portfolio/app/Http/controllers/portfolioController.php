<?php

namespace App\Http\Controllers;

use App\About;
use App\Addcontent;
use Illuminate\Http\Request;

class portfolioController extends Controller
{
    public function index(){
        $homeContents = Addcontent::where('published_status',1)->get();
        return view('front-end.home.home',['homeContents'=>$homeContents]);
    }

    public function aboutUs(){
        $aboutContents = About::where('published_status',1)->get();
        return view('front-end.about.about',['aboutContents'=>$aboutContents]);
    }
    public function projects(){
        return view('front-end.projects.project');
    }
    public function gallery(){
        return view('front-end.gallery.gallery');
    }
    public function contactUs(){
        return view('front-end.contact.contact');
    }
    public function adminHome(){
        return view('admin.home.home');
    }


}
