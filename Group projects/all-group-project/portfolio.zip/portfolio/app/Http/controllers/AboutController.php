<?php

namespace App\Http\Controllers;

use App\About;
use Illuminate\Http\Request;

class AboutController extends Controller
{
    public function newAboutContent(){
        return view('admin.about.new-about-content');
    }
    public function manageAboutContent(){
        $aboutContents = About::all();
        return view('admin.about.manage-about',['aboutContents'=>$aboutContents]);
    }
    public function saveAboutContent(Request $request){
        $about = new About();
        $about->about_title = $request->about_title;
        $about->about_content = $request->about_content;
        $about->published_status = $request->published_status;
        $about->save();

        return redirect('/about/content/new')->with('message', 'About Content Saved');
    }

    public function unpublishedAboutContent($id){
        $about = About::find($id);
        $about->published_status = 0;
        $about->save();
        return redirect('about/content/manage')->with('message','Your About unpublished');
    }
    public function publishedAboutContent($id){
        $about = About::find($id);
        $about->published_status = 1;
        $about->save();
        return redirect('about/content/manage')->with('message','Your About published');
    }
    public function editAboutContent($id){
        $aboutContent = About::find($id);
        return view('admin.about.edit-about',['aboutContent'=>$aboutContent]);
    }
    public function updateAboutContent(Request $request){
        $aboutContent = About::find($request->about_id);
        $aboutContent->about_title = $request->about_title;
        $aboutContent->about_content = $request->about_content;
        $aboutContent->published_status = $request->published_status;
        $aboutContent->save();

        return redirect('/about/content/manage')->with('message','About data update');
    }


    public function deleteAboutContent($id){
        $about = About::find($id);
        $about->delete();
        return redirect('about/content/manage')->with('message','About row deleted');
    }


}
