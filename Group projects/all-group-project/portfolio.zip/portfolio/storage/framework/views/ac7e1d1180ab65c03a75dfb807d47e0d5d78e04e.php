<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <header id="intro-carousel" class="carousel slide">
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <div class="item html5-video-container active">
                <!-- HTML5 Video -->
                <video muted autoplay loop poster="<?php echo e(asset('/')); ?>front/images/typing-on-mac.jpg" id="html5-video" class="fill">
                    <source src="<?php echo e(asset('/')); ?>front/videos/typing-on-mac.webm" type="video/webm">
                    <source src="<?php echo e(asset('/')); ?>front/videos/typing-on-mac.mp4" type="video/mp4">
                </video>
                <div class="carousel-caption">
                    <h1 class="animated slideInDown">I am MD. MONIRUL ISLAM</h1>
                    <h4 class="animated slideInDown" style="color: #FFFFFF">90/B(4th floor), Malibagh Chowdhury Para, D.I.T-Road.Dhaka-1219</h4>
                    <h4 class="animated slideInDown"style="color: #FFFFFF" >Mobile No 1: 01915047779</br>
                        E-mail : monirul89@gmail.com</h4>
                    <a href="#" class="btn btn-default btn-lg">MY RESUME</a>
                </div>
                <div class="html5-video-controls">
                    <a id="html5-video-volume" class="fa fa-volume-up fa-lg" href="#"></a>
                    <a id="html5-video-play" class="fa fa-pause fa-lg" href="#"></a>
                </div>
                <div class="overlay-detail"></div>
            </div><!-- /.item -->

        </div><!-- /.carousel-inner -->
        <div class="mouse"></div>
    </header>
    <section id="searvices">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center all_header all_p">
                    <h2>Destination of My Life</h2>
                    <h5></h5>
                    <p class="all_bdr"></p>
                </div>
            </div>

            <?php $__currentLoopData = $homeContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homeContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="row all_header">
                <div class="col-md-4 col-sm-6 text-center">
                    <div class="about_box box_shadow wow fadeInDown animated" data-wow-delay=".2s" data-wow-offset="100"
                         style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInDown;">
                        <h3 href="#"><img align="center" src="<?php echo e(asset('/')); ?>front/images/img/mision.png" width="300" height="100"></h3>
                        <div class="content-destination">

                            <?php echo $homeContent->mission_content; ?>


                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 text-center">
                    <div class="about_box box_shadow wow fadeInDown animated" data-wow-delay=".2s" data-wow-offset="100"
                         style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInDown;">
                        <h3><img src="<?php echo e(asset('/')); ?>front/images/img/vision.png" width="300" height="100"></h3>
                        <div class="content-destination">
                            <?php echo $homeContent->vission_content; ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 text-center">
                    <div class="about_box box_shadow wow fadeInDown animated" data-wow-delay=".2s" data-wow-offset="100"
                         style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInDown;">
                        <h3><img src="<?php echo e(asset('/')); ?>front/images/img/goal.png" width="200" height="100"></h3>
                        <div class="content-destination">
                            <?php echo $homeContent->goal_content; ?>

                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>


    <!-- I can Do part code ends -->
    <!--
        <section id="blogPost">
            <div class="container all_paragraph">
                <div class="row">
                    <div class="col-md-12 text-center all_header all_p">
                        <h2>Blog Posts</h2>
                        <h5>Lorem ipsum dolor sit amet, consectetur adipisicing elit. In, illo.</h5>
                        <p class="all_bdr"></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-md-3">
                        <div class="thumbnail text-justify blog all_hover wow fadeInLeft animated" data-wow-delay=".2s" data-wow-offset="100" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInLeft;">
                            <img src="<?php echo e(asset('/')); ?>front/images/blog-1.jpg" alt="..." class="img-responsive">
                            <div class="caption all_header">
                                <h3>Web Design</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo placeat eaque hic officiis alias laborum ullam, sint, iure, reiciendis omnis reprehenderit voluptatibus expedita. Minus perferendis aliquid molestiae soluta. Officiis alias ipsam eaque maiores sunt corporis aut aperiam, inventore sed maxime!</p>
                                <p class="text-right"><a href="#" class="" role="button">More >></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="thumbnail text-justify all_hover wow fadeInDown animated" data-wow-delay=".4s" data-wow-offset="100" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInDown;">
                            <img src="<?php echo e(asset('/')); ?>front/images/blog-2.jpg" alt="...">
                            <div class="caption all_header">
                                <h3>Web Development</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo placeat eaque hic officiis alias laborum ullam, sint, iure, reiciendis omnis reprehenderit voluptatibus expedita. Minus perferendis aliquid molestiae soluta. Officiis alias ipsam eaque maiores sunt corporis aut aperiam, inventore sed maxime!</p>
                                <p class="text-right"><a href="#" class="" role="button">More >></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="thumbnail text-justify all_hover wow fadeInDown animated" data-wow-delay=".6s" data-wow-offset="100" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInDown;">
                            <img src="<?php echo e(asset('/')); ?>front/images/blog-3.jpg" alt="...">
                            <div class="caption all_header">
                                <h3>Graphic Design</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo placeat eaque hic officiis alias laborum ullam, sint, iure, reiciendis omnis reprehenderit voluptatibus expedita. Minus perferendis aliquid molestiae soluta. Officiis alias ipsam eaque maiores sunt corporis aut aperiam, inventore sed maxime!</p>
                                <p class="text-right"><a href="#" class="" role="button">More >></a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-3">
                        <div class="thumbnail text-justify all_hover wow fadeInRight animated" data-wow-delay=".2s" data-wow-offset="100" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInRight;">
                            <img src="<?php echo e(asset('/')); ?>front/images/blog-4.jpg" alt="...">
                            <div class="caption all_header">
                                <h3>SEO</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo placeat eaque hic officiis alias laborum ullam, sint, iure, reiciendis omnis reprehenderit voluptatibus expedita. Minus perferendis aliquid molestiae soluta. Officiis alias ipsam eaque maiores sunt corporis aut aperiam, inventore sed maxime!</p>
                                <p class="text-right"><a href="#" class="" role="button">More >></a></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12 text-center wow fadeInUp viewallbtn animated" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInUp;">
                        <h6><a class="hvr-icon-spin" href="#">View All Post</a></h6>
                    </div>
                </div>
            </div>
        </section>
-->
    <!-- Blog Post code ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>