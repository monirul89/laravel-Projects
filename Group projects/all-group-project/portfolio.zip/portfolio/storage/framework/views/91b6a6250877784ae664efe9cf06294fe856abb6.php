<?php $__env->startSection('title'); ?>
    Edit Content
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="text-center text-success">Edit Home Page Content</h4>
                </div>
                <div class="panel-body">

                    <?php echo e(Form::open(['route'=>'mission-update', 'class'=>'form-horizontal', 'method'=>'POST' ])); ?>


                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Mission Title</label>
                            <div class="form-group col-md-8">
                                <input type="text" value="<?php echo e($addcontent->mission_title); ?>" name="mission_title" placeholder="Mission Title" class="form-control" />
                                <input type="hidden" value="<?php echo e($addcontent->id); ?>" name="mission_id"/>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Mission Content</label>
                            <div class="form-group col-md-8">
                                <textarea name="mission_content" class="form-control" id="editor"><?php echo e($addcontent->mission_content); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="control-label col-md-4">Publication Status</label>
                            <div class="col-md-8 radio">
                                <label><input type="radio" <?php echo e($addcontent->published_status == 1 ? 'checked' : ''); ?> name="published_status" />Published</label>
                                <label><input type="radio" <?php echo e($addcontent->published_status == 0 ? 'checked' : ''); ?> name="published_status" />Unublished</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="" class="control-label col-md-4"></label>
                            <div class="form-group col-md-8">
                                <input type="submit" name="btn" class="btn btn-success btn-block" value="Update Content" />
                            </div>
                        </div>

                    <?php echo e(Form::close()); ?>


                </div>
            </div>
        </div>
    </div>
    <!-- /#page-wrapper -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>