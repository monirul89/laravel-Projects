<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title> Manage About </title>

    <!-- Bootstrap Core CSS -->
    <link href="<?php echo e(asset('/')); ?>admin/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php echo e(asset('/')); ?>admin/vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="<?php echo e(asset('/')); ?>admin/vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo e(asset('/')); ?>admin/vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('/')); ?>admin/dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php echo e(asset('/')); ?>admin/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<body>

<div id="wrapper">

    <!-- Navigation -->
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <?php echo $__env->make('admin.includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /.navbar-top-links -->

    <?php echo $__env->make('admin.includes.side-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /.navbar-static-side -->
    </nav>

    <div id="page-wrapper">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header text-center">Home Content</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        DataTables Advanced Tables
                    </div>
                    <!-- /.panel-heading -->
                    <div class="panel-body">
                        <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                        <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                            <thead>
                            <tr>
                                <th>SL NO</th>
                                <th>ABOUT TITLE</th>
                                <th>ABOUT DESCRIPTION</th>
                                <th>PUBLISHED STATUS</th>
                                <th>ACTION</th>
                            </tr>
                            </thead>
                            <tbody>

                            <?php ($i=1); ?>
                            <?php $__currentLoopData = $aboutContents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutContent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr class="odd gradeX">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($aboutContent->about_title); ?></td>
                                <td>
                                    <?php echo $aboutContent->about_content; ?>

                                </td>

                                <td><?php echo e($aboutContent->published_status == 1 ? 'Published' : 'Unpublished'); ?></td>
                                <td class="center" width="80">
                                    <?php if($aboutContent->published_status == 1): ?>
                                    <a href="<?php echo e(route('unpublished-about-content', ['id'=>$aboutContent->id])); ?>" class="btn btn-info btn-xs">
                                        <span class="glyphicon glyphicon-arrow-up"></span>
                                    </a>
                                    <?php else: ?>
                                        <a class="btn btn-warning btn-xs" href="<?php echo e(route('published-about-content', ['id'=>$aboutContent->id])); ?>">
                                            <span class="glyphicon glyphicon-arrow-down"></span>
                                        </a>
                                    <?php endif; ?>
                                    <a class="btn btn-success btn-xs" href="<?php echo e(route('edit-about',['id'=>$aboutContent->id])); ?>">
                                        <span class="glyphicon glyphicon-edit"></span>
                                    </a>

                                    <a class="btn btn-danger btn-xs" href="<?php echo e(route('delete-about-content', ['id'=>$aboutContent->id])); ?>" onclick="return confirm('Are you sure to delete this !!')">
                                        <span class="glyphicon glyphicon-trash"></span>
                                    </a>
                                </td>
                            </tr>

                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
        </div>
    </div>
</div>
<!-- /#page-wrapper -->

</div>
<!-- /#wrapper -->
<!-- jQuery -->
<script src="<?php echo e(asset('/')); ?>admin/vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('/')); ?>admin/vendor/bootstrap/js/bootstrap.min.js"></script>

<!-- Metis Menu Plugin JavaScript -->
<script src="<?php echo e(asset('/')); ?>admin/vendor/metisMenu/metisMenu.min.js"></script>

<!-- DataTables JavaScript -->
<script src="<?php echo e(asset('/')); ?>admin/vendor/datatables/js/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('/')); ?>admin/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
<script src="<?php echo e(asset('/')); ?>admin/vendor/datatables-responsive/dataTables.responsive.js"></script>

<!-- Custom Theme JavaScript -->
<script src="<?php echo e(asset('/')); ?>admin/dist/js/sb-admin-2.js"></script>

<!-- Page-Level Demo Scripts - Tables - Use for reference -->
<script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
</script>

</body>

</html>