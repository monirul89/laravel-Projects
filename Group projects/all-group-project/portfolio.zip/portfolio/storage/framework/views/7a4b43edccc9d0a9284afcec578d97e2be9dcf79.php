<?php $__env->startSection('side-nav'); ?>

    <?php $__env->stopSection(); ?>