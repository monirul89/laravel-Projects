<?php $__env->startSection('title'); ?>
    Portfolio
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>



    
        
             
            
                 
                
            
            
                 

                
                    
                    
                        
                             
                             
                        
                             
                             
                        
                             
                             
                    
                    
                         
                        
                            
                                 
                                 
                        
                        
                             
                        
                             
                             
                        
                             
                             
                        
                             
                             
                    
                
                
                    
                    
                         
                        
                             
                            
                                 
                                
                            
                        
                        
                             
                            
                        
                        
                             
                            
                        
                        
                             
                            
                        
                    
                    
                         
                        
                             
                             
                        
                             
                             
                        
                             
                            
                        
                        
                             
                             
                        
                             
                             
                        
                             
                            
                        
                        
                             
                             
                        
                             
                             
                        
                             
                            
                        
                    
                    
                        
                             
                            
                                 
                                 
                            
                                 
                                 
                            
                                 
                                
                                
                            
                        
                        
                            
                                 
                                 
                            
                                 
                                 
                            
                                 
                                 
                        
                        
                            
                                 
                                 
                            
                                 
                                 
                            
                                 
                                 
                        
                        
                            
                                 
                                 
                            
                                 
                                 
                            
                                 
                                 
                        
                        
                            
                                 
                                 
                            
                                 
                                 
                            
                                 
                                 
                        
                        
                            
                                 
                                 
                            
                                 
                                 
                            
                                 
                                 
                        
                        
                            
                                 
                                 
                            
                                 
                                 
                            
                                 
                                 
                        
                    
                
                
                    
                    
                         
                        
                             
                        
                             
                            
                        
                    
                    
                         
                        
                             
                             
                        
                             
                            
                        
                        
                             
                            
                        
                    
                    
                         
                        
                             
                             
                        
                             
                        
                             
                            
                        
                    
                    
                         
                        
                             
                             
                        
                             
                            
                        
                        
                            
                        
                    
                    
                         
                        
                             
                             
                        
                             
                            
                        
                        
                             
                    
                    
                         
                        
                             
                             
                        
                             
                            
                        
                        
                             
                    
                    
                         
                        
                             
                             
                        
                             
                            
                        
                        
                             
                    
                    
                         
                        
                             
                             
                        
                             
                            
                        
                        
                             
                             
                        
                             
                             
                        
                             
                             
                        
                             
                             
                    
                
            
            
            
                 
                
                    
                        
                    
                
            
            
            
                 
                
                    
                
            
            
                 
                
                    
                
            
        
    
    

<!-- banner part end -->




<header id="intro-carousel" class="carousel slide">
    <!-- Wrapper for slides -->
    <div class="carousel-inner">
        <div class="item html5-video-container active">
            <!-- HTML5 Video -->
            <video muted autoplay loop poster="<?php echo e(asset('/')); ?>front/images/typing-on-mac.jpg" id="html5-video" class="fill">
                <source src="<?php echo e(asset('/')); ?>front/videos/typing-on-mac.webm" type="video/webm">
                <source src="<?php echo e(asset('/')); ?>front/videos/typing-on-mac.mp4" type="video/mp4">
            </video>
            <div class="carousel-caption">
                <h1 class="animated slideInDown">I am MD. MONIRUL ISLAM</h1>
                <h4 class="animated slideInDown" style="color: #FFFFFF">90/B(4th floor), Malibagh Chowdhury Para, D.I.T-Road.Dhaka-1219</h4>
                <h4 class="animated slideInDown"style="color: #FFFFFF" >Mobile No 1: 01915047779</br>
                    E-mail : monirul89@gmail.com</h4>
                <a href="#" class="btn btn-default btn-lg">MY RESUME</a>
            </div>
            <div class="html5-video-controls">
                <a id="html5-video-volume" class="fa fa-volume-up fa-lg" href="#"></a>
                <a id="html5-video-play" class="fa fa-pause fa-lg" href="#"></a>
            </div>
            <div class="overlay-detail"></div>
        </div><!-- /.item -->

    </div><!-- /.carousel-inner -->
    <div class="mouse"></div>
</header>

<section id="skills">
    <div class="container all_paragraph">
        <div class="col-md-12 col-sm-12">
            <div class="row">
                <h1 class="text-center">MD. MONIRUL ISLAM</h1>
                <div class="col-sm-12 text-center wow fadeInLeft animated"
                     data-wow-delay="0.2s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                    <div class="col-sm-9 text-justify all_header">
                        <p><strong>Address</strong>: 90/B, Khilgaon(4th floor), Malibagh <br />
                            Chowdhury Para. D.I.T-Road.Dhaka-1219 <br />
                            <strong>Mobile No 1</strong>: 01915047779 <br />
                            <strong>Mobile No 2 </strong>:01912191584. <br />
                            <strong>E-mail </strong>: monirul89@gmail.com, <br />mo7rul@gmail.com</p>
                    </div>
                     <div class="col-sm-3 text-justify all_header">
                         <img src="<?php echo e(asset('/')); ?>front/images/img/monir.jpg" alt="My Pic" width="150" height="150"/>
                    </div>

                </div>
            </div>
            <div class="paddingDiv col-sm-12"></div>
            <div class="paddingDiv col-sm-12"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 wow fadeInLeft animated"
                     data-wow-delay="0.5s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                    <div class="wow fadeInRight animated" data-wow-delay=".5s"
                         style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                        <h3 class="cv-title">Career Objective:</h3>
                        <p>To work willingly in an environment where success comes through creativity, hard work, sincerity, teamwork and commitment to duty.
                            Capable of working on a team with people at all levels as well as working independently.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 wow fadeInRight animated"
                     data-wow-delay="0.2s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
                    <div class="wow fadeInLeft animated" data-wow-delay=".2s"
                         style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                        <h3 class="cv-title">Career Summary:</h3>
                        <p>To build up career in a well known organization through the best effort. To obtain a responsible, challenging and growth-oriented position. Ability to learn new thing very quickly,
                            ability to find solution of problems quickly, capability of working under pressure and meeting deadlines.</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 wow fadeInLeft animated"
                     data-wow-delay="0.5s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                    <div class="wow fadeInLeft animated" data-wow-delay=".5s"
                         style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                        <h3 class="cv-title">Special Qualification:</h3>
                        <p>HTML5, CSS3, Row PHP, Laravel, JavaScript, jQuery, Adobe Illustrator CS, Adobe Photoshop CS.</p>
                        <p class="text-center"><img src="<?php echo e(asset('/')); ?>front/images/img/train.png" alt="Training course" height="200"></p>

                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-sm-12 wow fadeInRight animated"
                     data-wow-delay="0.5s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInRight;">
                    <div class="wow fadeInRight animated" data-wow-delay=".5s"
                         style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                        <table width="100%">
                            <tr id="pro" bgcolor="#b5b5b5">
                                <h3 class="cv-title">Professional Qualification:</h3>
                            </tr>
                            <tr>
                                <td colspan="2" >
                                    <table class="table">
                                        <tr>
                                            <th><h4>Certification</h4></th>
                                            <th><h4>Institute</h4></th>
                                            <th><h4>Location</h4></th>
                                            <th><h4>Duration</h4></th>
                                        </tr>
                                        <tr>
                                            <td>HTML5, CSS3, PHP, Wordpress.</td>
                                            <td>E-Futurebd.com</td>
                                            <td>Panthpat, Farmgate, Dhaka.</td>
                                            <td>6 month</td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
            <div class="paddingDiv"></div>
            <div class="row">
                <div class="col-md-12 col-sm-12 wow fadeInLeft animated"
                     data-wow-delay="0.8s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                    <div class="wow fadeInLeft animated" data-wow-delay=".8s"
                         style="visibility: visible; animation-delay: .8s; animation-name: fadeInLeft;">
                        <h3 class="cv-title">Specialization:</h3>
                        <ul>
                            <li><h5>HTML5/DHTML</h5></li>
                            <li><h5>CSS3</h5></li>
                            <li><h5>PHP 7</h5></li>
                            <li><h5>JavaScript</h5></li>
                            <li><h5>Adobe Photoshop</h5></li>
                            <li><h5>Illustrator</h5></li>
                            <li><h5>JQuery</h5></li>
                            <li><h5>Row PHP</h5></li>
                            <li><h5>Laravel</h5></li>
                        </ul>
                    </div>
                </div>
            </div>


        </div>

        <hr/>
        <div class="">
            <div class="col-sm-12">
                <h2 id="project">Projects </h2>
                <div class="row project-portfolio">
                    <div class="col-sm-12">
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 col-sm-12 skills_box text-center wow fadeInLeft animated"
                                     data-wow-delay="0.5s" data-wow-offset="50"
                                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                                    <div class="col-md-12 col-sm-12 text-justify all_header">
                                        <a target="_blank" href="http://shafidi.com">
                                            <h3>Project Name: Shafidi BD Import & Export</h3>
                                            <p>We are the leading exporter of Jute Sackings (Hessian or Burlap Bags, Hessian
                                                Twill or Burlap Flour Bags, Food grade Coffee Sacks,
                                                Burlap Feed/Grain Sacks, Heavy duty & plus size sacks, Jute/Burlap Sandbags,
                                                Jute Woolpacks, etc
                                            </p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 col-sm-12 skills_box wow fadeInRight animated" data-wow-delay=".2s"
                                     style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                                    <div class="text-justify all_header">
                                        <a target="_blank" href="http://shafidi.com">
                                            <img width="100%" height="100%" src="<?php echo e(asset('/')); ?>front/images/img/shafidi.jpg" alt="Shafidi">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 col-sm-12 skills_box text-center wow fadeInLeft animated"
                                     data-wow-delay="0.5s" data-wow-offset="50"
                                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                                    <div class="col-md-12 col-sm-12 text-justify all_header">
                                        <a target="_blank" href="http://www.fusion-radiology.com/">
                                            <h3>Project Name: Website for fusion-radiology</h3>
                                        <p>Fusion is UK based Tele-radiology Company that provides general and subspecialty
                                            reporting services to
                                            support existing radiology departments within NHS and private healthcare
                                            organizations.</p></a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 col-sm-12 skills_box wow fadeInRight animated" data-wow-delay=".2s"
                                     style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                                    <div class="text-justify all_header">
                                        <a target="_blank" href="http://www.fusion-radiology.com/">
                                            <img width="100%" height="100%" src="<?php echo e(asset('/')); ?>front/images/img/fusion-radiology.jpg" alt="Fusion">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 col-sm-12 skills_box text-center wow fadeInLeft animated"
                                     data-wow-delay="0.5s" data-wow-offset="50"
                                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                                    <div class="col-md-12 col-sm-12 text-justify all_header">
                                        <a target="_blank" href="http://themomsembroidery.com/">
                                            <h3>Project Name: The Mom's Embroidery</h3>
                                                <p>Learning common Hardanger Embroidery Stitches! Some of the Hardanger Embroidery
                                                    Stitches include Running Stitch,
                                                    Four Sided Stitch, Hem Stitch, Buttonhole Stitch, Squared Edging Stitch, Eyelet
                                                    Hole Stitch, Star Stitch.</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 col-sm-12 skills_box wow fadeInRight animated" data-wow-delay=".2s"
                                     style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                                    <div class="text-justify all_header">
                                        <a target="_blank" href="http://themomsembroidery.com/">
                                            <img width="100%" height="100%" src="<?php echo e(asset('/')); ?>front/images/img/themomsembroidery.jpg" alt="Embroidery">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 col-sm-12 skills_box text-center wow fadeInLeft animated"
                                     data-wow-delay="0.5s" data-wow-offset="50"
                                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                                    <div class="col-md-12 col-sm-12 text-justify all_header">
                                        <a target="_blank" href="http://funnymoney24.com">
                                        <h3>Project Name: Funny Money</h3>
                                        <p>We are the leading exporter of Jute Sackings (Hessian or Burlap Bags, Hessian
                                            Twill or Burlap Flour Bags, Food grade Coffee Sacks,
                                            Burlap Feed/Grain Sacks, Heavy duty & plus size sacks, Jute/Burlap Sandbags,
                                            Jute Woolpacks, etc</p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-6">
                                <div class="col-md-12 col-sm-12 skills_box wow fadeInRight animated" data-wow-delay=".2s"
                                     style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                                    <div class="text-justify all_header">
                                        <a target="_blank" href="http://funnymoney24.com">
                                            <img width="100%" height="100%" src="<?php echo e(asset('/')); ?>front/images/thumbs/funnymoney.jpg" alt="Funnymoney">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="paddingDiv clearfix"></div>
            <div class="col-md-12 col-sm-12 wow fadeInLeft animated"
                 data-wow-delay="0.8s" data-wow-offset="50"
                 style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                <div class="wow fadeInLeft animated" data-wow-delay=".8s"
                     style="visibility: visible; animation-delay: .8s; animation-name: fadeInLeft;">
                    <h3 class="cv-title">Extra Curricular Activities:</h3>
                    <p>Basic: Java, C, C++, C#.</p>
                </div>
            </div>
                <div class="col-md-12 col-sm-12 wow fadeInLeft animated"
                     data-wow-delay="0.8s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                    <div class="wow fadeInLeft animated" data-wow-delay=".8s"
                         style="visibility: visible; animation-delay: .8s; animation-name: fadeInLeft;">
                        <h3 class="cv-title">Personal Details :</h3>
                        <table class="table d-md-table-cell">
                            <tr>
                                <td>Father's Name</td>
                                <td>:</td>
                                <td> Jendar Ali Sarkar.</td>
                            </tr>
                            <tr>
                                <td>Mother's Name </td>
                                <td>:</td>
                                <td> Rakha Begum.</td>
                            </tr>
                            <tr>
                                <td>Date of Birth</td>
                                <td>:</td>
                                <td> February 12, 1989</td>
                            </tr>
                            <tr>
                                <td>Gender </td>
                                <td>:</td>
                                <td> Male</td>
                            </tr>
                            <tr>
                                <td>Marital Status </td>
                                <td>:</td>
                                <td> Unmarried</td>
                            </tr>
                            <tr>
                                <td>Nationality </td>
                                <td>:</td>
                                <td> Bangladeshi</td>
                            </tr>
                            <tr>
                                <td>National Id No </td>
                                <td>:</td>
                                <td> 8819451923222 </td>
                            </tr>
                            <tr>
                                <td> Religion </td>
                                <td>:</td>
                                <td> Islam </td>
                            </tr>
                            <tr>
                                <td> Permanent Address </td>
                                <td>:</td>
                                <td> Village-Char domdoma, Post- Bannakandi, Police station-Ullapara, District, Sirajgonj </td>
                            </tr>
                            <tr>
                                <td> Current Location </td>
                                <td>:</td>
                                <td> Dhaka </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
    <div class="container">
        <hr/>
    </div>
</section>

<section id="skills">
    <div class="container all_paragraph">
        <div class="col-md-12 col-sm-12 text-center all_header all_p">
            <h2>My awesome skills</h2>
            <h5>Web Development / Programming, Web Systems Administration (Apache, MySQL, PHP, Git), Database<br> Design
                and Query Optimization, Online Business Development</h5>
            <p class="all_bdr"></p>
        </div>
        <div class="col-md-12 col-sm-12">
            <div class="col-md-6 col-sm-6">
                <div class="col-md-12 col-sm-6 skills_box text-center wow fadeInLeft animated"
                     data-wow-delay=".2s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: .2s; animation-name: fadeInLeft;">
                    <div class="col-md-12 col-sm-12 text-justify all_header">
                        <h3>PSD to HTML </h3>
                        <p> I'm just the right choice for you. Well I'm Md. Monirul Islam a skilled Web
                            Designer, having long time experience in Web Design platform, specially from PSD to
                            HTML. <br/>&nbsp; </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="col-md-12 col-sm-6 skills_box wow fadeInRight animated" data-wow-delay=".4s"
                     data-wow-offset="50"
                     style="visibility: visible; animation-delay: .5s; animation-name: fadeInRight;">
                    <div class="col-md-12 col-sm-12 text-justify all_header">
                        <h3>Responsive Design</h3>
                        <p>I'm just a click away from you. Any type of responsive or basic design I can complete
                            it with your demanding time. Just try my work, I'm ready to share my experiences
                            with you.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12">
            <div class="col-md-6 col-sm-6">
                <div class="col-md-12  col-sm-6 skills_box text-center wow fadeInLeft animated"
                     data-wow-delay=".5s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: .7s; animation-name: fadeInLeft;">
                    <div class="col-md-12 col-sm-12 text-justify all_header">
                        <h3>PHP / mySQL</h3>
                        <p>I'm just the right choice for you. Well I'm Md. Monirul Islam a skilled Web
                            Developer, having long time experience in Web Development platform, specially
                            Dynamic and E-commerce website etc.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="col-md-12 col-sm-6 skills_box wow fadeInRight animated" data-wow-delay=".7s"
                     data-wow-offset="50"
                     style="visibility: visible; animation-delay: 1.5s; animation-name: fadeInRight;">
                    <div class="col-md-12 col-sm-12 text-justify all_header">
                        <h3>javaScript / jQuery </h3>
                        <p> One years of working on projects of different complexity including startups both in
                            frontend and backend. I have good skills in PHP 5(OOP), MySQL, JavaScript (jquery),
                            ajax, json. </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 col-sm-12">
            <div class="col-md-6 col-sm-6">
                <div class="col-md-12 col-sm-6 skills_box text-center wow fadeInLeft animated"
                     data-wow-delay="0.5s" data-wow-offset="50"
                     style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInLeft;">
                    <div class="col-md-12 col-sm-12 text-justify all_header">
                        <h3>MVC Frameworks</h3>
                        <p>Responsible and very ambitious, highly dedicated to his work and on a constant quest
                            for new, innovative solutions and ideas. Iinterested in programming and a logical
                            approach to problem solving.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-sm-6">
                <div class="col-md-12 col-sm-6 skills_box wow fadeInRight animated" data-wow-delay=".2s"
                     style="visibility: visible; animation-delay: .2s; animation-name: fadeInRight;">
                    <div class="col-md-12 col-sm-12 text-justify all_header">
                        <h3>Wordpress</h3>
                        <p>I am Wordpress speed optimization expert who can make your website as fast as
                            possible, I am resistant in my work until I achieve best possible results and get
                            everybody satisfied with project.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- skills Part code ends -->
<!-- About part code ends -->
<section id="contuct">
    <div class="container about_us">
        <div class="row">
            <div class="col-md-12 col-sm-12 text-center">
                <h2>Contact</h2>
                <p>Here is my contact information. Also, You can send me a message through the form.</p>
                <p class="all_bdr"></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3 col-sm-6 s_icon wow fadeInLeft animated" data-nahian-delay=".3s"
                 style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInLeft;">
                <h4>My Services</h4>
                <div class="line1"></div>
                <div class="line2"></div>
                <ul>
                    <li><a href="#"><i class="fa fa-stop"></i> Responsive Design</a></li>
                    <li><a href="#"><i class="fa fa-stop"></i> PSD to HTML Convert</a></li>
                    <li><a href="#"><i class="fa fa-stop"></i> Dynamic website</a></li>
                    <li><a href="#"><i class="fa fa-stop"></i> Web Development with PHP</a></li>
                    <li><a href="#"><i class="fa fa-stop"></i> MVC (Codeigniter/Laravel)</a></li>
                    <li><a href="#"><i class="fa fa-stop"></i> Web App Development</a></li>
                    <li><a href="#"><i class="fa fa-stop"></i> Wordpress Theme Customizing</a></li>
                    <li><a href="#"><i class="fa fa-stop"></i> WordPress Theme Development</a></li>
                    <li><a href="#"><i class="fa fa-stop"></i> Woo-Commerce Site</a></li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 s_icon_cont wow fadeInRight animated" data-nahian-delay=".3s"
                 style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;">
                <h4>contact info</h4>
                <div class="line11"></div>
                <div class="line22"></div>
                <ul>
                    <li>
                        <a href="https://www.google.com.bd/maps/@23.7611763,90.3633462,3a,75y,342.24h,106.82t/data=!3m6!1e1!3m4!1sUdLVB8o27kX56gfRvaqLlQ!2e0!7i13312!8i6656?hl=en"
                           target="_blank"><i class="fa fa-map-marker"></i> Address : <span>90/b, Malibagh Chowduripara, Dhaka-1219</span></a>
                    </li>
                    <li><a href="#"><i class="fa fa-phone"></i> +880 1915 047 779</a></li>
                    <li><a href="#"><i class="fa fa-envelope-o"></i> monirul89@gmail.com</a></li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6 wow fadeInRight animated" data-nahian-delay=".8s"
                 style="visibility: visible; animation-delay: 0.8s; animation-name: fadeInRight;">
                <h4>Get Direction</h4>
                <div class="line111"></div>
                <div class="line222"></div>

                <div class="google-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3651.669263058506!2d90.4195204998601!3d23.75917076893428!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8790228ce41%3A0x82c107410a23d95b!2s40+E+Rampura+Post+Office+Ln%2C+Dhaka!5e0!3m2!1sen!2sbd!4v1516599880672" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
                </div>
                <!-- /.google-map -->
                <h6 class="wow fadeInUp viewallbtn animated" data-wow-delay=".8s"
                    style="visibility: visible; animation-delay: .8s; animation-name: fadeInUp;"><a
                            class="hvr-ripple-out" href="#" data-toggle="modal" data-target="#exampleModal">drop me a
                        line hire me <span class="glyphicon glyphicon-send"></span></a></h6>
            </div>
            <div class="col-md-3 col-sm-6 s_icon_cont wow fadeInRight animated" data-nahian-delay=".3s"
                 style="visibility: visible; animation-delay: 0.3s; animation-name: fadeInRight;">
                <h4>Contact me</h4>
                <div class="line1111"></div>
                <div class="line2222"></div>

                <form action="#" method="post" class="wow fadeInRight animated" data-nahian-delay="1s"
                      style="visibility: visible; animation-delay: 1s; animation-name: fadeInRight;">
                    <div class="input-group">
                        <span class="input-group-addon" id="sizing-addon2"><i class="glyphicon glyphicon-user"></i></span>
                        <input type="text" class="form-control" placeholder="Please Enter your name"
                               aria-label="name" aria-describedby="sizing-addon2" name="name">
                        <span style="color:red"> </span></div>
                    <div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2"><i
                                        class="glyphicon glyphicon-earphone"></i></span>
                        <input type="text" class="form-control" placeholder="Please Enter your phone"
                               aria-label="Phone" aria-describedby="sizing-addon2" name="phone">
                        <span style="color:red"> </span></div>
                    <div class="input-group">
                            <span class="input-group-addon" id="sizing-addon2"><i
                                        class="glyphicon glyphicon-envelope"></i></span>
                        <input type="email" class="form-control" placeholder="Please Enter your email"
                               aria-label="Email" aria-describedby="sizing-addon2" name="email">
                        <span style="color:red"> </span></div>
                    <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-pencil-square-o"></i></span>
                        <textarea name="message" class="form-control"
                                  placeholder="Please Enter your message"></textarea>
                        <span style="color:red"> </span></div>
                    <a href="#">
                        <button type="submit" class="btn btn-primary">Send message <span
                                    class="glyphicon glyphicon-send"></span></button>
                    </a>
                </form>
            </div>
        </div>
    </div>
</section>
<!-- About part code ends -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front-end.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>